﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
	public class EDIActivityLog
	{

		public string Id { get; set; } = Guid.NewGuid().ToString();
		public string ActivityId { get; set; } = Guid.NewGuid().ToString();
		public string? UserId { get; set; } = Guid.NewGuid().ToString();
		public string? Status { get; set; } = "In Progress";
		public string? Category { get; set; } = string.Empty;
		public string? Comments { get; set; } = string.Empty;
		public string? PayRef { get; set; }
		public string? VendorName { get; set; }
		public DateTime? Starttime { get; set; } = DateTime.UtcNow;
		public DateTime? Endtime { get; set; }

		[ForeignKey("ActivityId")]
		public virtual EDIDetail EDIDetail { get; set; }
		[ForeignKey("UserId")]
		public virtual UserMaster UserMaster { get; set; }
	}
}
