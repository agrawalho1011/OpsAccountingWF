﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
    public class InvoiceDataLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string EmailActivitylogId { get; set; } = Guid.NewGuid().ToString();
        public string? InvoiceNo { get; set; }

        [ForeignKey("EmailActivitylogId")]
        public virtual EmailActivityLog EmailActivityLog { get; set; }
    }
}
