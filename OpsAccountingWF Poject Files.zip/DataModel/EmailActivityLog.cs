﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
	public class EmailActivityLog
	{
		public string Id { get; set; } = Guid.NewGuid().ToString();
		public string ActivityId { get; set; } = Guid.NewGuid().ToString();
		public string UserId { get; set; } = Guid.NewGuid().ToString();
		public string? Status { get; set; } = "In Progress";
		public string? Category { get; set; } 
		public string? Comments { get; set; }
		public string? PayRef { get; set; }
		public string? InvoiceNo { get; set; }
		public string? VendorName { get; set; }
		public DateTime? Starttime { get; set; } = DateTime.UtcNow;
		public DateTime? Endtime { get; set; }
		

		[ForeignKey("ActivityId")]
		public virtual EmailDetail EmailDetail { get; set; }

		[ForeignKey("UserId")]
		public virtual UserMaster UserMaster { get; set; }
	}
}
