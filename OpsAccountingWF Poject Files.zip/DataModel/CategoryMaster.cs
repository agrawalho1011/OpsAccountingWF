﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
    public class CategoryMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; }
        public string StatusId { get; set; }

        [ForeignKey("StatusId")]
        public virtual StatusMaster StatusMaster { get; set; }
    }
}
