﻿using System.ComponentModel.DataAnnotations;

namespace OpsAccountingWF.DataModel
{
    public class StatusMaster
    {
        [Key]
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? Name { get; set; }
    }
}
