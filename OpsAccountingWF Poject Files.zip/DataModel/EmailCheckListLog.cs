﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
    public class EmailCheckListLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string EmailActivitylogId { get; set; } = Guid.NewGuid().ToString();
        public string? Checklist { get; set; }
        public bool IsChecked { get; set; } = true;

        [ForeignKey("EmailActivitylogId")]
        public virtual EmailActivityLog EmailActivityLog { get; set; }
    }
}
