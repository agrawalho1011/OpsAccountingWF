﻿using System.ComponentModel.DataAnnotations;

namespace OpsAccountingWF.DataModel
{
    public class AccessTokenResponseMaster
    {
        [Key]
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string token_type { get; set; }
        public string scope { get; set; }
        public int expires_in { get; set; }
        public int ext_expires_in { get; set; }
        public string access_token { get; set; }
        public string? id_token { get; set; }
        public DateTime? AuthDateTime { get; set; } = DateTime.UtcNow;
        public bool? IsActive { get; set; }




    }


}
