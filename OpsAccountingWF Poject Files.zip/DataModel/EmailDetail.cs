﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
	public class EmailDetail
	{
		public string Id { get; set; } = Guid.NewGuid().ToString();
		public string FolderId { get; set; }
		public string UniqueKey { get; set; } = String.Empty;
		public string ConversationId { get; set; } = String.Empty;
		public string EmailSubject { get; set; } = String.Empty;
		public string UrlLink { get; set; } = string.Empty;
		public DateTime ReceivedTime { get; set; } = DateTime.UtcNow;
		public string? Sender { get; set; } = string.Empty;
		public bool  IsRead { get; set; } = false;
		public DateTime SyncDate { get; set; } = DateTime.UtcNow;
		public bool IsDelete { get; set; } = false;
		public int InLineAttachCount { get; set; } = 0;
		public int AttachCount { get; set; } = 0;
		public string EmailCategory { get; set; } = string.Empty;

		[ForeignKey("FolderId")]
		public virtual FolderMaster FolderMaster { get; set; }
        public virtual EmailActivityLog? EmailActivityLogs { get; set; }
	}
}
