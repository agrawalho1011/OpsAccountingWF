﻿namespace OpsAccountingWF.DataModel
{
    public class AuthenticationMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? TenantId { get; set; }
        public string? ClientId { get; set; }
        public string? RedirectUri { get; set; }
        public bool? IsActive { get; set; } = true;
    }
}
