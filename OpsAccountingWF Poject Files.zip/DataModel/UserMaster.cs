﻿using Microsoft.AspNetCore.Identity;

namespace OpsAccountingWF.DataModel
{
	public partial class UserMaster : IdentityUser
	{
		public UserMaster()
		{
		}
		public override string Id { get; set; } = Guid.NewGuid().ToString();
		public override string UserName { get; set; } 
		public string Wnsid { get; set; }
		public string CitrixId { get; set; }
		public bool IsActive { get; set; } = true;
		public bool IsDelete { get; set; } = false;
	}
}
