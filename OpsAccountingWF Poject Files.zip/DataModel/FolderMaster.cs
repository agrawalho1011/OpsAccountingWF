﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
	public class FolderMaster
	{
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string MailBoxId { get; set; } 
        public string FolderName { get; set; } = string.Empty;
        public string FolderId { get; set; } = string.Empty;
        public string ParenFolderId { get; set; } = string.Empty;
        public string? SyncState { get; set; }
        public DateTime? LastSyncDateTime { get; set; }
        public string? ChangeKey { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDelete { get; set; }


        [ForeignKey("MailBoxId")]
        public virtual EmailMaster EmailMaster { get; set; }

    }
}
