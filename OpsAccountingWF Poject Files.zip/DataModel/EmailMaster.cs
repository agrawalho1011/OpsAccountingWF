﻿using System.ComponentModel.DataAnnotations;

namespace OpsAccountingWF.DataModel
{
	public class EmailMaster
	{
		[Key]
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string EmailAddress { get; set; } = string.Empty;
        public string EmailPassword { get; set; } = string.Empty;
        public string Url { get; set; }
        public string? SyncState { get; set; }
        public string? AuthToken { get; set; }
        public DateTime? TokenLastUpdateDateTime { get; set; }
        public DateTime? LastSyncDateTime { get; set; }
        public bool? IsActive { get; set; }
        public bool IsDelete { get; set; }
    }
}
