﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
    public class EdiActivityLogHistory
    {
		public string Id { get; set; } = Guid.NewGuid().ToString();
		public string? EdilogId { get; set; } = Guid.NewGuid().ToString();
		public string? UserId { get; set; } = Guid.NewGuid().ToString();
		public string? Status { get; set; } 
		public string? Category { get; set; } = string.Empty;
		public string? Comments { get; set; } = string.Empty;
		public string? PayRef { get; set; }
		public string? VendorName { get; set; }
		public DateTime? Starttime { get; set; } = DateTime.UtcNow;
		public DateTime? Endtime { get; set; }
		public DateTime? InsertedDate { get; set; } = DateTime.UtcNow;
		public string? ApprovedUser { get; set; } 
		public DateTime? Lastmodifieddate { get; set; } 

		[ForeignKey("EdilogId")]
		public virtual EDIActivityLog EDIActivityLog { get; set; }
		[ForeignKey("UserId")]
		public virtual UserMaster UserMaster { get; set; }
	}
}
