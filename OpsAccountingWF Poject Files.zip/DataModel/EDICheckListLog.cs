﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
    public class EDICheckListLog
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string EDIActivitylogId { get; set; } = Guid.NewGuid().ToString();
        public string? Checklist { get; set; }
        public bool IsChecked { get; set; } = true;

        [ForeignKey("EDIActivitylogId")]
        public virtual EDIActivityLog EDIActivityLog { get; set; }
    }
}
