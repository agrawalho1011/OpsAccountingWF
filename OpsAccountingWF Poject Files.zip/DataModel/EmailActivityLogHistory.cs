﻿using System.ComponentModel.DataAnnotations.Schema;

namespace OpsAccountingWF.DataModel
{
    public class EmailActivityLogHistory
    {
		public string Id { get; set; } = Guid.NewGuid().ToString();
		public string? EmaillogId { get; set; } = Guid.NewGuid().ToString();
		public string? UserId { get; set; } = Guid.NewGuid().ToString();
		public string? Status { get; set; }
		public string? Category { get; set; } = string.Empty;
		public string? Comments { get; set; } = string.Empty;
		public string? PayRef { get; set; }
		public DateTime? Starttime { get; set; } = DateTime.UtcNow;
		public DateTime? Endtime { get; set; }
		public DateTime? InsertedDate { get; set; } = DateTime.UtcNow;
		
		[ForeignKey("EmaillogId")]
		public virtual EmailActivityLog EmailActivityLog { get; set; }
		[ForeignKey("UserId")]
		public virtual UserMaster UserMaster { get; set; }
	}
}
