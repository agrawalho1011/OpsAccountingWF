﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace OpsAccountingWF.DataModel
{
	public class ApplicationDbContext : IdentityDbContext<UserMaster>
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
		: base(options)
		{
		}
		public virtual DbSet<UserMaster> UserMaster { get; set; }
		public DbSet<EmailDetail> EmailDetail { get; set; }
		public DbSet<EDIDetail> EDIDetail { get; set; }
		public DbSet<FolderMaster> FolderMaster { get; set; }
		public DbSet<EmailMaster> EmailMaster { get; set; }
		public DbSet<ThreadMaster> ThreadMaster { get; set; }
		public DbSet<MapMaster> MapMaster { get; set; }
		public DbSet<EDIActivityLog> EDIActivityLog { get; set; }
		public DbSet<EmailActivityLog> EmailActivityLog { get; set; }
		public DbSet<InvoiceDataLog> InvoiceDataLog { get; set; }
		public DbSet<EmailCheckListLog> EmailCheckListLog { get; set; }
		public DbSet<EDICheckListLog> EDICheckListLog { get; set; }
		public DbSet<StatusMaster> StatusMaster { get; set; }
		public DbSet<CategoryMaster> CategoryMaster { get; set; }
		public DbSet<EdiActivityLogHistory> EdiActivityLogHistory { get; set; }
		public DbSet<EmailActivityLogHistory> EmailActivityLogHistory { get; set; }
		public DbSet<AccessTokenResponseMaster> AccessTokenResponseMaster { get; set; }
		public DbSet<AuthenticationMaster> AuthenticationMaster { get; set; }

	}
}
