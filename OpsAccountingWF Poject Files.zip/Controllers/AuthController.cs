﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using OpsAccountingWF.DataModel;

public class AuthController : Controller
{
    private readonly IConfiguration _configuration;
    private readonly IHttpClientFactory _httpClientFactory;
    ApplicationDbContext _ctx;
    public AuthController(IConfiguration configuration, IHttpClientFactory httpClientFactory,ApplicationDbContext ctx)
    {
        _configuration = configuration;
        _httpClientFactory = httpClientFactory;
        _ctx = ctx;
    }

    [HttpGet]
    public IActionResult Login()
    {
        var authmaster = _ctx.AuthenticationMaster.Where(x => x.IsActive == true).FirstOrDefault();
        //var clientId = "f64cb9ac-f813-4488-9f57-34590d700eb8";
        //var tenantId = "19470c39-fb57-4cea-8f8d-7c581679a164";
        //var redirectUri = "https://localhost:7188/Auth/Callback";
        var state = Guid.NewGuid().ToString();
        var nonce = Guid.NewGuid().ToString();

		var authorizationRequest = $"https://login.microsoftonline.com/{authmaster.TenantId}/oauth2/v2.0/authorize?" +
								 $"client_id={authmaster.ClientId}&" +
								 $"redirect_uri={authmaster.RedirectUri}&" +
								 $"response_type=code&" +
								 $"scope=https%3A%2F%2Foutlook.office365.com%2FEWS.AccessAsUser.All&" +
								 $"state={state}&" +
								 $"nonce={nonce}&" +
								 $"prompt=consent";
        Console.WriteLine("**********************************************************//////&&&&");
        Console.WriteLine(authorizationRequest);
		Console.WriteLine("**********************************************************//////&&&&");
		return Redirect(authorizationRequest);
    }

    //[HttpGet("Auth/Callback")]
    //public async Task<IActionResult> Callback(string code)
    //{
    //    ViewData["authmaster"] = _ctx.AuthenticationMaster.Where(x => x.IsActive == true).FirstOrDefault();
    //    ViewData["code"] = code;
    //    return View();
    //}

    [HttpGet("Auth/Callback")]
    public async Task<IActionResult> Callback(string code)
    {
        var authmaster = _ctx.AuthenticationMaster.Where(x => x.IsActive == true).FirstOrDefault();
        //var clientId = "f64cb9ac-f813-4488-9f57-34590d700eb8";
        //var tenantId = "19470c39-fb57-4cea-8f8d-7c581679a164";
        //var redirectUri = "https://localhost:7188/Auth/Callback";

        var tokenRequest = new HttpRequestMessage(HttpMethod.Post, $"https://login.microsoftonline.com/{authmaster.TenantId}/oauth2/v2.0/token");
        tokenRequest.Content = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("client_id", authmaster.ClientId),
            new KeyValuePair<string, string>("redirect_uri", authmaster.RedirectUri),
            new KeyValuePair<string, string>("code", code),
            new KeyValuePair<string, string>("grant_type", "authorization_code"),
        });

        var httpClient = _httpClientFactory.CreateClient();
        var tokenResponse = await httpClient.SendAsync(tokenRequest);

        if (!tokenResponse.IsSuccessStatusCode)
        {
            return BadRequest("Failed to obtain access token");
        }

        var tokenResponseContent = await tokenResponse.Content.ReadAsStringAsync();

        Console.WriteLine(tokenResponseContent);


        var accessToken = JsonConvert.DeserializeObject<AccessTokenResponseMaster>(tokenResponseContent);
        // Store the access token in a secure location, such as the ASP.NET Core
        // memory cache or a database, so that it can be reused later.
        if (accessToken != null)
        {
            accessToken.IsActive = true;
            _ctx.AccessTokenResponseMaster.Add(accessToken);
            _ctx.SaveChanges();
        }


        return RedirectToAction("ShowUploadData", "Admin");
    }
}
