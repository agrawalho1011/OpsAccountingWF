﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OpsAccountingWF.DataModel;
using OpsAccountingWF.Models;

namespace OpsAccountingWF.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<UserMaster> userManger;
        private readonly SignInManager<UserMaster> signInManager;
        private readonly RoleManager<IdentityRole> roleManager;
        public ApplicationDbContext _ctx;


        public AccountController(UserManager<UserMaster> userManger, SignInManager<UserMaster> signInManager, RoleManager<IdentityRole> roleManager, ApplicationDbContext ctx)
        {
            this.userManger = userManger;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            _ctx = ctx;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpGet]

        public IActionResult Index()
        {
            ViewData["roles"] = roleManager.Roles.ToList();

            var result = _ctx.Users.Select(x => new RegisterViewModel
            {
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                Wnsid = x.Wnsid,
                Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId,
                UserId = x.Id,
                isActive = x.IsActive
            }).ToList();
            return View(result);
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {

            if (ModelState.IsValid)
            {
                var result = await signInManager.PasswordSignInAsync(model.CitrixId, model.Password, false, false);
                if (result.Succeeded)
                {
                    var user = await userManger.FindByNameAsync(model.CitrixId);
                    var roles = await userManger.GetRolesAsync(user);
                    if (roles.Count != 0)
                    {
                        if (roles[0].ToString() == "Manager")
                        {
                            return RedirectToAction("ShowUploadData", "Admin");
                        }
                        else if (roles[0].ToString() == "Administrator")
                        {
                            return RedirectToAction("ShowUploadData", "Admin");
                        }
                        else
                        {
                            return RedirectToAction("GetItem", "Invoice");
                        }
                    }
                }
                //ModelState.AddModelError("", "Invalid Login Attempt");
                return View(model);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }


        }

        [HttpGet]
        public IActionResult Register()
        {
            ViewData["roles"] = roleManager.Roles.ToList();

            //ViewData["Roles"] = _ctx.Roles.Select(x => new RoleManager
            //{
            //	Id = x.Id,
            //	Name = x.Name

            //}).ToList();

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new UserMaster
                {
                    CitrixId = model.CitrixId,
                    Wnsid = model.Wnsid,
                    UserName = model.CitrixId
                };

                _ctx.UserRoles.Add(new IdentityUserRole<string>
                {
                    RoleId = model.Role,
                    UserId = user.Id,
                });

                var result = await userManger.CreateAsync(user);
                _ctx.SaveChanges();
                if (result.Succeeded)
                {
                    //await userManger.AddToRoleAsync(user, model.Role);

                    return RedirectToAction("Index", "Account");
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }

            return View(model);
        }

        [HttpPost]
        public async Task<JsonResult> UpdateRole(UpdateRoleModel data)
        {

            var user = _ctx.Users.Where(x => x.CitrixId == data.CitrixId).FirstOrDefault();
            var userrole = _ctx.UserRoles.Where(x => x.UserId == user.Id).FirstOrDefault();

            if (user != null)
            {
                try
                {
                    _ctx.Remove(userrole);
                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = data.RoleId,
                        UserId = user.Id,
                    });
                    
                    _ctx.SaveChanges();

                    //var role = _ctx.UserRoles.Where(x => x.UserId == user.Id).FirstOrDefault();
                    //               var roletoUpdate = _ctx.Roles.Where(x => x.Id == data.RoleId).FirstOrDefault();


                    //               await userManger.RemoveFromRoleAsync(user, role.RoleId);

                    //               //UserMaster user_update = _ctx.Users.Where(x => x.CitrixId == data.CitrixId).FirstOrDefault();

                    //               await userManger.AddToRoleAsync(user, roletoUpdate.Id);

                }
                catch (Exception ex) { }
                return Json("success");
            }
            else
            {
                return Json("failed");
            }

        }

        [HttpGet]
        public IActionResult Edit(string CitrixId)
        {
            ViewData["userdata"] = _ctx.Users.Where(x => x.Id == CitrixId).Select(x => new RegisterViewModel
            {
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                Wnsid = x.Wnsid,
                UserId = x.Id,
                isActive = x.IsActive

            }).FirstOrDefault();
            return PartialView();
        }

        [HttpPost]

        public async Task<JsonResult> Edit(RegisterViewModel model)
        {
            var user = _ctx.Users.Where(x => x.Id == model.UserId).FirstOrDefault();
            if(user != null)
            {
                user.CitrixId = model.CitrixId;
                user.UserName = model.UserName;
                user.Wnsid = model.Wnsid;
                _ctx.Users.Update(user);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }

        public JsonResult Activate(string Id)
        {
            string message = "";
            if (Id != null)
            {
                var master = _ctx.Users.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    _ctx.Users.Update(master);
                    _ctx.SaveChanges();
                    message = master.IsActive == true ? "User Activated!" : "User Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");

        }
    }
}
