﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using OpsAccountingWF.DataModel;
using OpsAccountingWF.Models;

namespace OpsAccountingWF.Controllers
{
    public class ThreadMasterController : Controller
    {
        ApplicationDbContext _context;
        public ThreadMasterController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.ThreadMaster.AsEnumerable());
            
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewData["FolderMaster"] = _context.FolderMaster.OrderBy(x => x.IsActive).ThenBy(x => x.FolderName).ToList();

            return PartialView();

        }

        [HttpPost]
        public JsonResult Create(ThreadMasterViewModel model)
        {
            if (ModelState.IsValid)
            {
                if(model.IsEmail == false)
                {
                    model.ThreadFolderId = "";
                }
                ThreadMaster thread = _context.ThreadMaster.Where(x => x.ThreadName == model.ThreadName && x.IsEmail == model.IsEmail).FirstOrDefault();
                if (thread == null)
                {
                    _context.ThreadMaster.Add(
                        new ThreadMaster
                        {
                            ThreadName = model.ThreadName,
                            IsEmail = model.IsEmail,
                            isActive = true,
                            ThreadFolderId = model.ThreadFolderId,
                            CreatedDateTime = DateTime.UtcNow,
                        });

                    _context.SaveChanges();
                }
                else
                {
                    return Json("Duplicate");
                }
               
                return Json("Success");
            }
            else
            {
                return Json("Something went wrong");
            }  
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            ThreadMaster master = _context.ThreadMaster.Where(x => x.Id == (id)).Select(x => new ThreadMaster
            {
                ThreadName = x.ThreadName,
                IsEmail = x.IsEmail,
                ThreadFolderId = x.ThreadFolderId,

            }).FirstOrDefault();

            ViewData["FolderMaster"] = _context.FolderMaster.OrderBy(x => x.IsActive).ThenBy(x => x.FolderName).ToList();
            return View(master);
        }

        public JsonResult Activate(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ThreadMaster master = _context.ThreadMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.isActive = master.isActive != null ? !master.isActive : true;
                    _context.ThreadMaster.Update(master);
                    _context.SaveChanges();
                    message = master.isActive == true ? "Email Activated!" : "Email Deactivated!";
                   
                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }
    }
}
