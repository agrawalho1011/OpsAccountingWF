﻿using Microsoft.AspNetCore.Mvc;
using OpsAccountingWF.DataModel;
using OpsAccountingWF.Models;

namespace OpsAccountingWF.Controllers
{
    public class MapMasterController : Controller
    {
        ApplicationDbContext _context;
        public MapMasterController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(_context.MapMaster.AsEnumerable());
        }

        [HttpGet]

        public IActionResult Create()
        {
            ViewData["ThreadMaster"] = _context.ThreadMaster.OrderBy(x => x.isActive).Where(x => x.IsEmail == false).ToList();
            return PartialView();

        }
        [HttpPost]
        public JsonResult Create(MapMasterViewModel model)
        {
            if (ModelState.IsValid)
            {
                MapMaster map = _context.MapMaster.Where(x => x.Account == model.Account && x.CompanyName.Trim() == model.CompanyName.Trim()).FirstOrDefault();
                if (map == null)
                {
                    _context.MapMaster.Add(
                        new MapMaster
                        {
                           Account = model.Account,
                           CompanyName = model.CompanyName,
                           Type = model.Type,
                           ActivityType = model.ActivityType,
                        });
                    _context.SaveChanges();
                }
                else
                {
                    map.Account = model.Account;
                    map.CompanyName = model.CompanyName;
                    map.Type = model.Type;
                    map.ActivityType = _context.ThreadMaster.Where(x => x.Id == model.ActivityType).Select(x => x.ThreadName).FirstOrDefault();
                    _context.MapMaster.Update(map);
                    _context.SaveChanges();
                    return Json("Updated Successfully..!");
                }

                return Json(ModelState);
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpGet]

        public IActionResult Edit(string Id)
        {
            MapMaster master = _context.MapMaster.Where(x => x.Id == Id).FirstOrDefault();
            ViewData["ThreadMaster"] = _context.ThreadMaster.OrderBy(x => x.isActive).Where(x => x.IsEmail == false).ToList();
            return PartialView(master);
        }

        [HttpPost]
        public async Task<JsonResult> Edit(MapMaster model)
        {
            var actcount = _context.MapMaster.Where(x => x.Id == model.Id).FirstOrDefault();
            var actname = _context.ThreadMaster.Where(x => x.Id == model.ActivityType && x.IsEmail == false).Select(x => x.ThreadName).FirstOrDefault();
            if (actcount != null)
            {
                actcount.Account = model.Account;
                actcount.CompanyName = model.CompanyName;
                
                actcount.ActivityType = actname;
                _context.MapMaster.Update(actcount);

                _context.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }
    }
}
