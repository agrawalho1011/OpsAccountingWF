﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using OpsAccountingWF.DataModel;
using OpsAccountingWF.Models;
using System.Security.Claims;

namespace OpsAccountingWF.Controllers
{
    [Authorize]
    public class InvoiceController : Controller
    {

        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public InvoiceController(ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor)
        {
            _ctx = ctx;
            _httpContextAccessor = httpContextAccessor;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "User,Administrator")]
        public IActionResult GetItem()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var todays = DateTime.UtcNow.Date;
            ViewData["thread"] = _ctx.ThreadMaster.Where(x => x.isActive == true).OrderBy(x => x.IsEmail).ThenBy(x => x.ThreadName).ToList();
            ViewData["status"] = _ctx.StatusMaster.ToList();

            var log = _ctx.EmailActivityLog.Where(x => x.Starttime.Value.Date == todays && x.UserId == userid).Select(x => EF.Functions.DateDiffSecond(x.Starttime, x.Endtime)).Sum();
            var EDIlog = _ctx.EDIActivityLog.Where(x => x.Starttime.Value.Date == todays && x.UserId == userid).Select(x => EF.Functions.DateDiffSecond(x.Starttime, x.Endtime)).Sum();
            TimeSpan t = TimeSpan.FromSeconds(log.Value) + TimeSpan.FromSeconds(EDIlog.Value);


            ViewData["TotalTime"] = t.ToString(@"hh\:mm\:ss");
            return View();
        }

        public IActionResult Allocate(string threadId)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var folId = _ctx.ThreadMaster.Where(x => x.Id == threadId).Select(x => x.ThreadFolderId).FirstOrDefault();
            var todays = DateTime.UtcNow.Date;
            List<EmailActivityLog> emaillog = new List<EmailActivityLog>();
            //emaillog = _ctx.EmailActivityLog.Include(x => x.EmailDetail).Where(x => x.UserId == userid && x.Status == "In Progress" && x.EmailDetail.FolderMaster.Id == folId).ToList();
            var resultEmail = _ctx.EmailActivityLog.Include(x => x.EmailDetail).Where(x => x.UserId == userid && x.Status == "In Progress" && x.EmailDetail.FolderMaster.Id == folId).FirstOrDefault();
            var resultEDI = _ctx.EDIActivityLog.Include(x => x.EDIDetail).Where(x => x.UserId == userid && x.Status == "In Progress" && x.EDIDetail.Activity == threadId).FirstOrDefault();
            if (resultEmail != null)
            {
                resultEmail.Starttime = DateTime.UtcNow;
                _ctx.EmailActivityLog.Update(resultEmail);
                _ctx.SaveChanges();
                return Json(resultEmail);
            }
            else if (resultEDI != null)
            {
                resultEDI.Starttime = DateTime.UtcNow;
                _ctx.EDIActivityLog.Update(resultEDI);
                _ctx.SaveChanges();
                return Json(resultEDI);
            }
            else
            {
                if (userid != null && threadId != "undefined")
                {

                    List<SqlParameter> parms = new List<SqlParameter>
                    {
						// Create parameter(s)    
						new SqlParameter { ParameterName = "@threadId", Value = threadId },
                        new SqlParameter { ParameterName = "@userId", Value = userid }
                    };


                    var data = _ctx.Database.ExecuteSqlRaw("GetAllocatedItem @threadId, @userId", parms.ToArray());

                    EmailActivityLog emailActivityLog = _ctx.EmailActivityLog.Include(x => x.EmailDetail).Where(x => x.UserId == userid && x.Status == "In Progress").FirstOrDefault();

                    if (emailActivityLog != null)
                    {
                        emailActivityLog.Starttime = DateTime.UtcNow;
                        _ctx.EmailActivityLog.Update(emailActivityLog);
                        _ctx.SaveChanges();
                        return Json(emailActivityLog);
                    }

                    EDIActivityLog ediActivityLog = _ctx.EDIActivityLog.Include(x => x.EDIDetail).Where(x => x.UserId == userid && x.Status == "In Progress").FirstOrDefault();

                    if (ediActivityLog != null)
                    {
                        ediActivityLog.Starttime = DateTime.UtcNow;
                        _ctx.EDIActivityLog.Update(ediActivityLog);
                        _ctx.SaveChanges();
                        return Json(ediActivityLog);
                    }
                    return Json("No Data");
                }
                return Json("Failed");
            }

            //return Json("Failed");

        }

        [HttpPost]
        public async Task<JsonResult> UpdateEmailActivityLog(EmailActivityLogViewModel model)
        {
            if (ModelState.IsValid)
            {   
                EmailActivityLog log = _ctx.EmailActivityLog.Where(x => x.Id == model.Id).FirstOrDefault();
                //EmailActivityLog eactlog = new EmailActivityLog();
                try
                {
                    if (log != null)
                    {
                        if (model.EmailLists != null)
                        {
                            foreach (var elist in model.EmailLists)
                            {
                                if (log.Status == "In Progress")
                                {
                                    log.InvoiceNo = elist.InvoiceNumber;
                                    log.PayRef = elist.Payref;
                                    log.VendorName = elist.Vendor;
                                    log.Status = elist.Status;
                                    log.Category = elist.Category;
                                    log.Comments = elist.Comments;
                                    log.Endtime = DateTime.UtcNow;
                                    _ctx.EmailActivityLog.Update(log);
                                }
                                else
                                {
                                    EmailActivityLog eactlog = new EmailActivityLog
                                    {
                                        Id = elist.InvoiceId,
                                        InvoiceNo = elist.InvoiceNumber,
                                        PayRef = elist.Payref,
                                        VendorName = elist.Vendor,
                                        Status = elist.Status,
                                        Category = elist.Category,
                                        Comments = elist.Comments,
                                        Starttime = log.Endtime,
                                        ActivityId = log.ActivityId,
                                        UserId = log.UserId,
                                        Endtime = DateTime.UtcNow,

                                    };
                                    _ctx.EmailActivityLog.Add(eactlog);
                                }
                                _ctx.SaveChanges();

                                foreach (var check in model.CheckLists)
                                {
                                    var res = _ctx.EmailCheckListLog.Where(x => x.Checklist == check.ChecklistName && x.EmailActivitylogId == check.EmailActivitylogId).FirstOrDefault();
                                    if (res != null)
                                    {
                                        //res.Checklist = check.ChecklistName;
                                        res.IsChecked = check.CheckListValue;
                                        _ctx.EmailCheckListLog.Update(res);

                                    }
                                    else
                                    {
                                        if (check.EmailActivitylogId == elist.InvoiceId)
                                        {
                                            _ctx.EmailCheckListLog.Add(new EmailCheckListLog
                                            {
                                                Id = Guid.NewGuid().ToString(),
                                                EmailActivitylogId = check.EmailActivitylogId,
                                                Checklist = check.ChecklistName,
                                                IsChecked = check.CheckListValue

                                            });
                                        }
                                    }
                                }
                                _ctx.SaveChanges();

                            }

                        }
                        else
                        {
                            return Json("All fields are mandatory.!");
                        }
                    }
                    else
                    {
                        return Json("Error while processing the request");
                    }


                    //EmailMaster master = _ctx.EmailMaster.Where(x => x.EmailAddress.Contains("invoicesusa") && x.IsActive == true).FirstOrDefault();

                    //service = email.ConnectService(master.EmailAddress, master.EmailPassword, master.Url);

                    //string ukey = _ctx.EmailActivityLog.Where(x => x.Id == model.Id).Select(x => x.EmailDetail.UniqueKey).FirstOrDefault();

                    //email.UpdateEmailCategory(model.EmailCategory, service, ukey);

                    //EmailServices email = new EmailServices();
                    //ExchangeService service = email.ConnectService("u310475", "Vnl@123@", "https://email.wns.com/EWS/Exchange.asmx");

                    //string ukey = _ctx.EmailActivityLog.Where(x => x.Id == model.Id).Select(x => x.EmailDetail.UniqueKey).FirstOrDefault();
                    //email.UpdateEmailCategory(model.EmailCategory, service, ukey);

                    _ctx.SaveChanges();
                }
                catch (Exception ex)
                {

                }
                return Json(log);

            }
            else
            {
                return Json("Error while processing the request");
            }

        }

        [HttpPost]

        public async Task<JsonResult> UpdateEDIActivityLog(EDIActivityLogViewModel model)
        {
            if (ModelState.IsValid)
            {
                EDIActivityLog log = _ctx.EDIActivityLog.Where(x => x.Id == model.Id).FirstOrDefault();

                try
                {
                    if (log != null)
                    {
                        if (log.Status == "In Progress")
                        {
                            log.PayRef = model.Payref;
                            log.VendorName = model.Vendor;
                            log.Status = model.Status;
                            log.Category = model.Category;
                            log.Comments = model.Comments;
                            log.Endtime = DateTime.UtcNow;
                            _ctx.EDIActivityLog.Update(log);
                        }
                        else
                        {
                            _ctx.EDIActivityLog.Add(new EDIActivityLog
                            {
                                PayRef = model.Payref,
                                VendorName = model.Vendor,
                                Status = model.Status,
                                Category = model.Category,
                                Comments = model.Comments,
                                Starttime = log.Starttime,
                                ActivityId = log.ActivityId,
                                UserId = log.UserId,
                                Endtime = DateTime.UtcNow,

                            });
                        }
                    }
                    if (model.Chklist != null && model.Chklist != "")
                    {
                        string[] checklist = model.Chklist.Split(new char[] { ',' });
                        foreach (var chlist in checklist)
                        {
                            if (chlist == "Item1")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Duplicate invoice, CN/DN",
                                    IsChecked = true,
                                });
                            }
                            else if (chlist == "Item2")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Supplier Name, Supplier Ref, Invoice date, Invoice Amt. & Currency",
                                    IsChecked = true,
                                });
                            }
                            else if (chlist == "Item3")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Container/HBL/MBL/Booking / Truck /File/ IT/ LOT Number",
                                    IsChecked = true,
                                });
                            }
                            else if (chlist == "Item3")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Department of File(I/E),Future ETA & Disposition status",
                                    IsChecked = true,
                                });
                            }
                            else if (chlist == "Item5")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Valid Estimate (Supplier Name, Amt. Currency, BL/Cntr, Charge & Free Desc.)",
                                    IsChecked = true,
                                });
                            }
                            else if (chlist == "Item6")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Estimate Not Valid (File Contact & File Profit(I/E) & Valid Comments",
                                    IsChecked = true,
                                });
                            }
                            else
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Invoice Scanned",
                                    IsChecked = true,
                                });
                            }

                        }
                    }
                    if (model.UnChklist != null && model.UnChklist != "")
                    {
                        string[] unchecklist = model.UnChklist.Split(new char[] { ',' });
                        foreach (var unchlist in unchecklist)
                        {
                            if (unchlist == "Item1")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Duplicate invoice, CN/DN",
                                    IsChecked = false,
                                });
                            }
                            else if (unchlist == "Item2")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Supplier Name, Supplier Ref, Invoice date, Invoice Amt. & Currency",
                                    IsChecked = false,
                                });
                            }
                            else if (unchlist == "Item3")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Container/HBL/MBL/Booking / Truck /File/ IT/ LOT Number",
                                    IsChecked = false,
                                });
                            }
                            else if (unchlist == "Item3")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Department of File(I/E),Future ETA & Disposition status",
                                    IsChecked = false,
                                });
                            }
                            else if (unchlist == "Item5")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Valid Estimate (Supplier Name, Amt. Currency, BL/Cntr, Charge & Free Desc.)",
                                    IsChecked = false,
                                });
                            }
                            else if (unchlist == "Item6")
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Estimate Not Valid (File Contact & File Profit(I/E) & Valid Comments",
                                    IsChecked = false,
                                });
                            }
                            else
                            {
                                _ctx.EDICheckListLog.Add(new EDICheckListLog
                                {
                                    EDIActivitylogId = log.Id,
                                    Checklist = "Invoice Scanned",
                                    IsChecked = false,
                                });
                            }

                        }

                    }

                    var checkpyaref = _ctx.EmailActivityLog.Where(x => x.PayRef == model.Payref && (x.Status != "Completed" && x.Status != "Already Processed")).FirstOrDefault();

                    if(checkpyaref != null && (model.Status == "Completed" || model.Status == "Already Processed"))
                    {
                        _ctx.Add(new EmailActivityLogHistory
                        {
                            Id = Guid.NewGuid().ToString(),
                            EmaillogId = checkpyaref.Id,
                            UserId = checkpyaref.UserId,
                            Status = checkpyaref.Status,
                            Category = checkpyaref.Category,
                            Comments = checkpyaref.Comments,
                            Starttime = checkpyaref.Starttime,
                            Endtime = checkpyaref.Endtime,
                            PayRef = checkpyaref.PayRef,
                            InsertedDate = DateTime.UtcNow

                        });

                        checkpyaref.Status = model.Status;
                        _ctx.EmailActivityLog.Update(checkpyaref);
                        //checkpyaref
                    }



                    _ctx.SaveChanges();

                }
                catch (Exception ex)
                {

                }
                return Json(log);

            }
            else
            {
                return Json("Error while processing the request");
            }
        }

        [HttpGet]
        public JsonResult GetCount()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var result = _ctx.EmailActivityLog.ToList();
            var result1 = _ctx.EDIActivityLog.ToList();
            productionCountViewModel model = new productionCountViewModel
            {
                EmailProcessed = result.Where(x => x.UserId == userid && x.Status != "In Process" && x.Starttime.Value.ToShortDateString() == DateTime.UtcNow.ToShortDateString()).Count(),
                EdiProcessed = result1.Where(x => x.UserId == userid && x.Status != "In Process" && x.Starttime.Value.ToShortDateString() == DateTime.UtcNow.ToShortDateString()).Count(),

            };

            return Json(model);


        }

        [HttpGet]
        public IActionResult getAllocatedCount()
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            List<productionCountViewModel> model = new List<productionCountViewModel>();

            var result = _ctx.EmailActivityLog.Include(x => x.EmailDetail).Where(x => x.UserId == userid && x.Status == "In Progress").
                GroupBy(x => x.EmailDetail.FolderMaster.Id).Select(grp => new productionCountViewModel
                {
                    TotalAllocated = grp.Count(),
                    ThreadName = _ctx.ThreadMaster.Where(x => x.ThreadFolderId == grp.Key).Select(x => x.ThreadName).FirstOrDefault(),
                    Type = "Email"

                }).ToList();
            model.AddRange(result);

            result = _ctx.EDIActivityLog.Include(x => x.EDIDetail).Where(x => x.UserId == userid && x.Status == "In Progress").
                GroupBy(x => x.EDIDetail.Activity).Select(grp => new productionCountViewModel
                {
                    TotalAllocated = grp.Count(),
                    ThreadName = _ctx.ThreadMaster.Where(x => x.Id == grp.Key).Select(x => x.ThreadName).FirstOrDefault(),
                    Type = "EDI"

                }).ToList();

            model.AddRange(result);
            //var result1 = _ctx.EDIActivityLog.Where(x => x.UserId == userid && x.Status == "In Progress").ToList();
            return Json(model);


        }

        [HttpGet]

        public JsonResult GetCategoryList(string Id)
        {
            var result = _ctx.CategoryMaster.Where(x => x.StatusId == Id).ToList();
            if (result == null)
            {
                return Json("Something went wrong..!");
            }
            else
            {
                return Json(result);
            }
        }

        [HttpPost]

        public JsonResult SaveCheckList(EmailCheckListLogViewModel model)
        {
            return Json("Success");
        }

        public IActionResult FreeTextForm()
        {
            ViewData["status"] = _ctx.StatusMaster.ToList();
            return View();
        }

        [HttpPost]

        public async Task<JsonResult> InsertFreeText(FreeTextFormViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (ModelState.IsValid)
            {
                var edi = _ctx.EDIDetail.Where(x => x.Payref == model.Payref).FirstOrDefault();
                if (edi != null)
                {
                    var log = _ctx.EDIActivityLog.Where(x => x.PayRef == model.Payref).FirstOrDefault();
                    if (log != null)
                    {
                        log.PayRef = model.Payref;
                        log.VendorName = model.Vendor;
                        log.Comments = model.Comments;
                        log.Category = model.Category;
                        log.Status = model.Status;
                        log.UserId = userid;
                        log.Starttime = DateTime.UtcNow;
                        log.Endtime = DateTime.UtcNow;
                        _ctx.EDIActivityLog.Update(log);
                        _ctx.SaveChanges();

                        return Json("Details Updated Sucessfully.!");
                        //Update EDIActivityLog
                    }
                    else
                    {
                        _ctx.EDIActivityLog.Add(new EDIActivityLog
                        {
                            ActivityId = edi.Id,
                            UserId = userid,
                            Status = model.Status,
                            Category = model.Category,
                            Starttime = DateTime.UtcNow,
                            Endtime = DateTime.UtcNow.AddSeconds(10),
                            PayRef = model.Payref,
                            VendorName = model.Vendor,
                            Comments = model.Comments

                        });
                        _ctx.SaveChanges();
                        //Insert into EDIActivityLog
                        return Json("Processed..!");
                    }
                }
                else
                {
                    EDIDetail eddetails = new EDIDetail
                    {

                        Id = Guid.NewGuid().ToString(),
                        LegalEntity = "",
                        Account_Code = model.Vendor,
                        Supplier_Name = "",
                        File_Number = "",
                        BL = "",
                        Type = "",
                        Payref = model.Payref,
                        Invoice_date = "",
                        Date_Create = null,
                        DESCRIPTION = "",
                        ARInvCreatedBy = "",
                        AMOUNT = model.Amt,
                        Currency = "",
                        CODE = "",
                        Rejection = "",
                        SuppRef = model.Suppref,
                        ETA_ETD = "",
                        ApproveUser = "",
                        Application = "",
                        last_Modify_Date = null,
                        Disposition = "",
                        Activity = ""
                    };
                    _ctx.EDIDetail.Add(eddetails);

                    _ctx.EDIActivityLog.Add(new EDIActivityLog
                    {
                        ActivityId = eddetails.Id,
                        UserId = userid,
                        Status = model.Status,
                        Category = model.Category,
                        Comments = model.Comments,
                        PayRef = model.Payref,
                        VendorName = model.Vendor,
                        Starttime = DateTime.UtcNow,
                        Endtime = DateTime.UtcNow.AddSeconds(10),
                    });
                    _ctx.SaveChanges();
                    //Insert into EDIDetail
                    //Insert Into EDIActivityLog
                    return Json("Processed..!");
                }
            }
            else
            {
                return Json("Error while processing the request");
            }

        }
    }
}
