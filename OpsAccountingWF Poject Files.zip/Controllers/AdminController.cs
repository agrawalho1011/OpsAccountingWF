﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OpsAccountingWF.DataModel;
using OpsAccountingWF.Models;
using System.Linq.Dynamic.Core;
using System.Diagnostics;
using System.Security.Claims;
using ClosedXML.Excel;
using System.Data;
using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Text;

namespace OpsAccountingWF.Controllers
{
    public class AdminController : Controller
    {
        private IWebHostEnvironment hostingEnvironment;
        public ApplicationDbContext _ctx;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AdminController(IWebHostEnvironment hostingEnvironment, ApplicationDbContext ctx, IHttpContextAccessor httpContextAccessor)
        {
            this.hostingEnvironment = hostingEnvironment;
            _ctx = ctx;
            _httpContextAccessor = httpContextAccessor;
        }

        [Authorize(Roles = "Administrator,User")]
        public IActionResult Dashboard()
        {
            ViewData["thread"] = _ctx.ThreadMaster.Where(x => x.isActive == true).OrderBy(x => x.IsEmail).ThenBy(x => x.ThreadName).ToList();
            return View();
        }

        public IActionResult ActivityDashboard()
        {
            List<DashboardModel> dashboardModel = new List<DashboardModel>();

            var result = from EmailDetail in _ctx.EmailDetail
                         join EmailActivityLog in _ctx.EmailActivityLog
                         on EmailDetail.Id equals EmailActivityLog.ActivityId into details
                         from m in details.DefaultIfEmpty()
                         where EmailDetail.IsDelete == false
                         group m by new
                         {
                             EmailDetail.FolderMaster.Id,
                             Days = EF.Functions.DateDiffDay(EmailDetail.ReceivedTime, DateTime.UtcNow),
                             Hours = EF.Functions.DateDiffHour(EmailDetail.ReceivedTime, DateTime.UtcNow)
                         } into grp
                         select new DashboardModel()
                         {
                             FolderId = grp.Key.Id,
                             Days = grp.Key.Days,
                             Hours = grp.Key.Hours,
                             Completed = grp.Where(x => x.ActivityId != null).Count(),
                             Pending = grp.Where(x => x.ActivityId == null).Count(),
                             Total = grp.Count(),
                         };

            //mul.DashboardModel = result.ToList();
            dashboardModel.AddRange(result.ToList());

            result = from EDIDetail in _ctx.EDIDetail
                     join EDIActivityLog in _ctx.EDIActivityLog
                     on EDIDetail.Id equals EDIActivityLog.ActivityId into details
                     from m in details.DefaultIfEmpty()
                     where EDIDetail.Activity != ""
                     group m by new
                     {
                         EDIDetail.Activity,
                         Days = EF.Functions.DateDiffDay(EDIDetail.Date_Create, DateTime.UtcNow),
                         Hours = EF.Functions.DateDiffHour(EDIDetail.Date_Create, DateTime.UtcNow)
                     } into grp
                     select new DashboardModel()
                     {
                         FolderId = grp.Key.Activity,
                         Days = grp.Key.Days,
                         Hours = grp.Key.Hours,
                         Completed = grp.Where(x => x.ActivityId != null).Count(),
                         Pending = grp.Where(x => x.ActivityId == null).Count(),
                         Total = grp.Count(),
                     };

            dashboardModel.AddRange(result.ToList());

           
            return Json(dashboardModel);
        }

        [Authorize(Roles = "Administrator")]
        public IActionResult UserDashboard(DateTime? StartDate, DateTime? EndDate)
        {
            List<UserDashboardModel> userdashboardModel = new List<UserDashboardModel>();
            if (StartDate != null && EndDate != null)
            {
                //List<DashboardModel> dashboardModel = new List<DashboardModel>();


                ViewData["thread"] = _ctx.ThreadMaster.OrderBy(x => x.IsEmail).ThenBy(x => x.ThreadName).ToList();
                ViewData["User"] = _ctx.Users.OrderBy(x => x.UserName).ToList();

                var data = _ctx.EmailActivityLog.Where(x => x.Starttime.Value.Date >= StartDate.Value.Date && x.Endtime.Value.Date <= EndDate.Value.Date).Include(x => x.EmailDetail).GroupBy(x => new
                {
                    x.UserMaster.UserName,

                }).Select(x => new UserDashboardModel
                {
                    User = x.Key.UserName,
                    Count = x.Count(),

                }).ToList();

                foreach (UserDashboardModel dashboard in data)
                {
                    dashboard.ThreadData = _ctx.EmailActivityLog.Where(x => x.UserMaster.UserName == dashboard.User && x.Starttime.Value.Date >= StartDate.Value.Date && x.Endtime.Value.Date <= EndDate.Value.Date).Include(x => x.EmailDetail).ThenInclude(x => x.FolderMaster)
                    .GroupBy(x =>
                    new
                    {
                        x.EmailDetail.FolderMaster.Id,
                        x.Status,

                    }).Select(x => new ThreadCount
                    {
                        Count = x.Count(),
                        Status = x.Key.Status,
                        Thread = x.Key.Id,

                    }).ToList();
                }

                userdashboardModel.AddRange(data);


                data = _ctx.EDIActivityLog.Where(x => x.Starttime.Value.Date >= StartDate.Value.Date && x.Endtime.Value.Date <= EndDate.Value.Date).Include(x => x.EDIDetail).GroupBy(x => new
                {
                    x.UserMaster.UserName,

                }).Select(x => new UserDashboardModel
                {
                    User = x.Key.UserName,
                    Count = x.Count(),

                }).ToList();

                foreach (UserDashboardModel dashboard in data)
                {
                    dashboard.EDIThreadData = _ctx.EDIActivityLog.Where(x => x.UserMaster.UserName == dashboard.User && x.Starttime.Value.Date >= StartDate.Value.Date && x.Endtime.Value.Date <= EndDate.Value.Date).Include(x => x.EDIDetail)
                    .GroupBy(x =>
                    new
                    {
                        x.EDIDetail.Activity,
                        x.Status,

                    }).Select(x => new EDIThreadCount
                    {
                        Count = x.Count(),
                        Status = x.Key.Status,
                        Thread = x.Key.Activity,

                    }).ToList();
                }

                userdashboardModel.AddRange(data);
            }
            else
            {
                //List<UserDashboardModel> userdashboardModel = new List<UserDashboardModel>();

                ViewData["thread"] = _ctx.ThreadMaster.OrderBy(x => x.IsEmail).ThenBy(x => x.ThreadName).ToList();
                ViewData["User"] = _ctx.Users.OrderBy(x => x.UserName).ToList();

                var data = _ctx.EmailActivityLog.Include(x => x.EmailDetail).GroupBy(x => new
                {
                    x.UserMaster.UserName,

                }).Select(x => new UserDashboardModel
                {
                    User = x.Key.UserName,
                    Count = x.Count(),

                }).ToList();

                foreach (UserDashboardModel dashboard in data)
                {
                    dashboard.ThreadData = _ctx.EmailActivityLog.Where(x => x.UserMaster.UserName == dashboard.User).Include(x => x.EmailDetail).ThenInclude(x => x.FolderMaster)
                    .GroupBy(x =>
                    new
                    {
                        x.EmailDetail.FolderMaster.Id,
                        x.Status,

                    }).Select(x => new ThreadCount
                    {
                        Count = x.Count(),
                        Status = x.Key.Status,
                        Thread = x.Key.Id,

                    }).ToList();
                }

                userdashboardModel.AddRange(data);


                data = _ctx.EDIActivityLog.Include(x => x.EDIDetail).GroupBy(x => new
                {
                    x.UserMaster.UserName,

                }).Select(x => new UserDashboardModel
                {
                    User = x.Key.UserName,
                    Count = x.Count(),

                }).ToList();

                foreach (UserDashboardModel dashboard in data)
                {
                    dashboard.EDIThreadData = _ctx.EDIActivityLog.Where(x => x.UserMaster.UserName == dashboard.User).Include(x => x.EDIDetail)
                    .GroupBy(x =>
                    new
                    {
                        x.EDIDetail.Activity,
                        x.Status,

                    }).Select(x => new EDIThreadCount
                    {
                        Count = x.Count(),
                        Status = x.Key.Status,
                        Thread = x.Key.Activity,

                    }).ToList();
                }

                userdashboardModel.AddRange(data);
            }
            return View(userdashboardModel);
        }

        [Authorize(Roles = "Administrator")]
        public IActionResult DailyProducation(DateTime? StartDate)
        {
            StartDate = StartDate == null ? DateTime.UtcNow : StartDate;
            ViewData["User"] = _ctx.Users.Select(x => x.UserName).ToList();

            List<DailyProductionViewModel> emailData = _ctx.EmailActivityLog.Where(x => x.Starttime.Value.Date == StartDate.Value.Date && x.Status != "In Progress").Select(x => new DailyProductionViewModel { Username = x.UserId, TotalProd = EF.Functions.DateDiffSecond(x.Starttime, x.Endtime) }).GroupBy(x => x.Username).Select(g =>
                       new DailyProductionViewModel
                       {
                           Username = g.Key,
                           Email = g.Count(),
                           TotalProd = g.Sum(x => x.TotalProd)
                       }
            ).ToList();


            List<DailyProductionViewModel> ediData = _ctx.EDIActivityLog.Where(x => x.Starttime.Value.Date == StartDate.Value.Date && x.Status != "In Progress").Select(x => new DailyProductionViewModel { Username = x.UserId, TotalProd = EF.Functions.DateDiffSecond(x.Starttime, x.Endtime) }).GroupBy(x => x.Username).Select(g =>
                      new DailyProductionViewModel
                      {
                          Username = g.Key,
                          EDI = g.Count(),
                          TotalProd = g.Sum(x => x.TotalProd)
                      }
            ).ToList();

            List<DailyProductionViewModel> data = new List<DailyProductionViewModel>();

            foreach (UserMaster user in _ctx.Users)
            {

                var edi = ediData.Where(x => x.Username == user.Id).FirstOrDefault();
                var email = emailData.Where(x => x.Username == user.Id).FirstOrDefault();

                data.Add(new DailyProductionViewModel
                {
                    Username = user.UserName,
                    Email = (email != null ? email.Email : 0),
                    EDI = (edi != null ? edi.EDI : 0),
                    EmailCount = (edi != null ? edi.EDI : 0) + (email != null ? email.Email : 0),
                    TotalProd = (edi != null ? edi.TotalProd : 0) + (email != null ? email.TotalProd : 0),
                });
            }


            return View(data);
        }


        [Authorize(Roles = "Administrator")]
        public IActionResult Upload()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Upload(List<IFormFile> files)
        {
            try
            {
                if (files != null)
                {
                    int i = 0;
                    List<EDIDetail> edi = new List<EDIDetail>();
                    List<EDIDetail> eDIDetails = new List<EDIDetail>();
                    string ediFilePath = "";
                    string dispFilepath = "";
                    string documentFilePath = "";
                    IEnumerable<EDIActivityLog> activityLogs = _ctx.EDIActivityLog;
                    foreach (IFormFile file in files)
                    {
                        string uploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "mediaUpload");
                        string filePath = Path.Combine(uploadsFolder, file.FileName);
                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            file.CopyTo(fileStream);
                        }

                        //DataTable dt = GeneralFunction.GetDataFromExcel(filePath);
                        //if (i == 0)
                        //{
                        //    ediFilePath = filePath;
                        //}
                        //else
                        //{
                        //    dispFilepath = filePath;
                        //}
                        if (i == 0)
                        {
                            ediFilePath = filePath;
                        }
                        else if (i == 1)
                        {
                            //documentFilePath = filePath;
                            dispFilepath = filePath;
                        }
                        else
                        {
                            documentFilePath = filePath;
                        }

                        i = i + 1;
                    }

                    edi = GeneralFunction.GetListFromExcel(ediFilePath);
                    DataTable dt_webReport = GeneralFunction.GetDataFromExcel(dispFilepath);
                    DataTable dt_document = GeneralFunction.GetDataFromExcel(documentFilePath);
                    var edis = _ctx.EDIDetail.ToList();

                    var grpedi = edi.Where(x => x.Rejection != "1" && (x.ApproveUser.ToLower() == "opstowns" || x.ApproveUser.ToLower() == "futureeta" || x.ApproveUser == "Invalidref" || x.ApproveUser == "")).GroupBy(x => new
                    {
                        x.Payref,
                        x.Account_Code,
                        x.SuppRef

                    }).Select(x => new EDIDetail
                    {
                        LegalEntity = x.Select(x => x.LegalEntity).FirstOrDefault(),
                        Account_Code = x.Key.Account_Code,
                        Supplier_Name = x.Select(x => x.Supplier_Name).FirstOrDefault(),
                        File_Number = x.Select(x => x.File_Number).FirstOrDefault(),
                        BL = x.Select(x => x.BL).FirstOrDefault(),
                        Type = x.Select(x => x.Type).FirstOrDefault(),
                        Payref = x.Key.Payref,
                        Invoice_date = x.Select(x => x.Invoice_date).FirstOrDefault(),
                        Date_Create = x.Select(x => x.Date_Create).FirstOrDefault(),
                        DESCRIPTION = x.Select(x => x.DESCRIPTION).FirstOrDefault(),
                        ARInvCreatedBy = x.Select(x => x.ARInvCreatedBy).FirstOrDefault(),
                        AMOUNT = x.Select(x => x.AMOUNT.HasValue ? x.AMOUNT.Value : 0).Sum(),
                        Currency = x.Select(x => x.Currency).FirstOrDefault(),
                        CODE = x.Select(x => x.CODE).FirstOrDefault(),
                        Rejection = x.Select(x => x.Rejection).FirstOrDefault(),
                        SuppRef = x.Key.SuppRef,
                        ETA_ETD = x.Select(x => x.ETA_ETD).FirstOrDefault(),
                        ApproveUser = x.Select(x => x.ApproveUser).FirstOrDefault(),
                        Application = x.Select(x => x.Application).FirstOrDefault(),
                        last_Modify_Date = x.Select(x => x.last_Modify_Date).FirstOrDefault(),
                        Disposition = x.Select(x => x.Disposition).FirstOrDefault(),
                        Activity = x.Select(x => x.Activity).FirstOrDefault(),

                    }).ToList();

                    foreach (EDIDetail e in grpedi)
                    {

                        var dup = edis.Where(x => x.Payref == e.Payref && x.Account_Code == e.Account_Code && x.SuppRef == e.SuppRef).FirstOrDefault();

                        if (dup == null)
                        {
                            if (e.SuppRef == "NAVOTI220392590")
                            {
                                string hold = "";
                            }

                            DataRow dr = dt_webReport.AsEnumerable().Where(x => x.Field<string>("PayableRef") == e.Payref).FirstOrDefault();
                            DataRow drdocument;
                            if (dr != null)
                            {
                                e.Disposition = dr["DispositionDescription"].ToString();
                            }

                            if (dt_document.Rows.Count == 0)
                            {
                                drdocument = null;
                            }
                            else
                            {
                                drdocument = dt_document.AsEnumerable().Where(x => x.Field<string>("PayableRef") == e.Payref && x.Field<string>("Document") != "").FirstOrDefault();
                            }

                            if (drdocument != null)
                            {
                                var isPayRefExist = activityLogs.Where(x => x.PayRef == drdocument["PayableRef"].ToString()).FirstOrDefault();

                                if (isPayRefExist == null)
                                {
                                    if (e.ApproveUser.ToLower() == "futureeta" && e.Disposition.ToLower() != "data entry")
                                    {
                                        if (e.last_Modify_Date.Value < DateTime.UtcNow.AddDays(-10))

                                            eDIDetails.Add(e);
                                        //_ctx.EDIDetail.Add(e);
                                    }
                                    else if (e.ApproveUser.ToLower() == "opstowns")
                                    {
                                        eDIDetails.Add(e);
                                        //_ctx.EDIDetail.Add(e);
                                    }
                                    else if (e.ApproveUser.Trim() == "Invalidref")
                                    {
                                        eDIDetails.Add(e);
                                        //_ctx.EDIDetail.Add(e);
                                    }
                                    else if (e.ApproveUser == "")
                                    {
                                        e.ApproveUser = "Unassigned";
                                        eDIDetails.Add(e);
                                        //_ctx.EDIDetail.Add(e);
                                    }

                                }

                            }
                            else
                            {
                                //var emailpayref = _ctx.EmailActivityLog.Where(x => x.PayRef.Trim() == e.Payref.Trim()).FirstOrDefault();

                                //if (emailpayref == null)
                                //{
                                if (e.ApproveUser.ToLower() == "futureeta" && e.Disposition.ToLower() != "data entry")
                                {
                                    if (e.last_Modify_Date.Value < DateTime.UtcNow.AddDays(-10))
                                        _ctx.EDIDetail.Add(e);
                                }
                                else if (e.ApproveUser.ToLower() == "opstowns")
                                {
                                    _ctx.EDIDetail.Add(e);
                                }
                                else if (e.ApproveUser.Trim() == "Invalidref")
                                {
                                    _ctx.EDIDetail.Add(e);
                                }
                                else if (e.ApproveUser == "")
                                {
                                    e.ApproveUser = "Unassigned";
                                    _ctx.EDIDetail.Add(e);
                                }
                                //}
                            }

                        }
                        else
                        {
                            if (e.ApproveUser.ToLower() == "opstowns")
                            {
                                var Edilog = _ctx.EDIActivityLog.Where(x => x.PayRef == dup.Payref).FirstOrDefault();
                                //var edihistory = _ctx.EdiActivityLogHistory.Where(x => x.EdilogId == Edilog.Id).FirstOrDefault();
                                if (Edilog != null)
                                {
                                    _ctx.EdiActivityLogHistory.Add(new EdiActivityLogHistory
                                    {
                                        Id = Guid.NewGuid().ToString(),
                                        EdilogId = Edilog.Id,
                                        UserId = Edilog.UserId,
                                        Status = Edilog.Status,
                                        Category = Edilog.Category,
                                        Comments = Edilog.Comments,
                                        Starttime = Edilog.Starttime,
                                        Endtime = Edilog.Endtime,
                                        PayRef = Edilog.PayRef,
                                        VendorName = Edilog.VendorName,
                                        InsertedDate = DateTime.UtcNow,
                                        ApprovedUser = Edilog.EDIDetail.ApproveUser,
                                        Lastmodifieddate = Edilog.EDIDetail.last_Modify_Date
                                    });

                                    Edilog.Status = "In Progress";
                                    Edilog.Category = null;
                                    Edilog.Starttime = null;
                                    Edilog.Endtime = null;
                                    Edilog.PayRef = null;
                                    Edilog.VendorName = null;

                                    _ctx.EDIActivityLog.Update(Edilog);
                                    _ctx.SaveChanges();
                                }
                            }
                            else if (e.ApproveUser.ToLower() == "futureeta" && dup.last_Modify_Date != null && e.last_Modify_Date < DateTime.UtcNow.AddDays(-10))
                            {
                                var Edilog = _ctx.EDIActivityLog.Where(x => x.PayRef == dup.Payref).FirstOrDefault();
                                //var edihistory = _ctx.EdiActivityLogHistory.Where(x => x.EdilogId == Edilog.Id).FirstOrDefault();
                                if (Edilog != null)
                                {
                                    _ctx.EdiActivityLogHistory.Add(new EdiActivityLogHistory
                                    {
                                        Id = Guid.NewGuid().ToString(),
                                        EdilogId = Edilog.Id,
                                        UserId = Edilog.UserId,
                                        Status = Edilog.Status,
                                        Category = Edilog.Category,
                                        Comments = Edilog.Comments,
                                        Starttime = Edilog.Starttime,
                                        Endtime = Edilog.Endtime,
                                        PayRef = Edilog.PayRef,
                                        VendorName = Edilog.VendorName,
                                        InsertedDate = DateTime.UtcNow,
                                        ApprovedUser = Edilog.EDIDetail.ApproveUser,
                                        Lastmodifieddate = Edilog.EDIDetail.last_Modify_Date

                                    });

                                    Edilog.Status = "In Progress";
                                    Edilog.Category = null;
                                    Edilog.Starttime = null;
                                    Edilog.Endtime = null;
                                    Edilog.PayRef = null;
                                    Edilog.VendorName = null;

                                    _ctx.EDIActivityLog.Update(Edilog);
                                    _ctx.SaveChanges();
                                }
                            }
                            else if (e.ApproveUser == "Invalidref" && dup.last_Modify_Date != null && e.last_Modify_Date < DateTime.UtcNow.AddDays(-10))
                            {
                                var Edilog = _ctx.EDIActivityLog.Where(x => x.PayRef == dup.Payref).FirstOrDefault();
                                if (Edilog != null)
                                {
                                    _ctx.EdiActivityLogHistory.Add(new EdiActivityLogHistory
                                    {
                                        Id = Guid.NewGuid().ToString(),
                                        EdilogId = Edilog.Id,
                                        UserId = Edilog.UserId,
                                        Status = Edilog.Status,
                                        Category = Edilog.Category,
                                        Comments = Edilog.Comments,
                                        Starttime = Edilog.Starttime,
                                        Endtime = Edilog.Endtime,
                                        PayRef = Edilog.PayRef,
                                        VendorName = Edilog.VendorName,
                                        InsertedDate = DateTime.UtcNow,
                                        ApprovedUser = Edilog.EDIDetail.ApproveUser,
                                        Lastmodifieddate = Edilog.EDIDetail.last_Modify_Date

                                    });

                                    Edilog.Status = "In Progress";
                                    Edilog.Category = null;
                                    Edilog.Starttime = null;
                                    Edilog.Endtime = null;
                                    Edilog.PayRef = null;
                                    Edilog.VendorName = null;

                                    _ctx.EDIActivityLog.Update(Edilog);
                                    _ctx.SaveChanges();
                                }
                            }

                            dup.LegalEntity = e.LegalEntity;
                            dup.Account_Code = e.Account_Code;
                            dup.Supplier_Name = e.Supplier_Name;
                            dup.File_Number = e.File_Number;
                            dup.BL = e.BL;
                            dup.Type = e.Type;
                            dup.Payref = e.Payref;
                            dup.Invoice_date = e.Invoice_date;
                            dup.Date_Create = e.Date_Create;
                            dup.DESCRIPTION = e.DESCRIPTION;
                            dup.ARInvCreatedBy = e.ARInvCreatedBy;
                            dup.AMOUNT = e.AMOUNT;
                            dup.Currency = e.Currency;
                            dup.CODE = e.CODE;
                            dup.Rejection = e.Rejection;
                            dup.SuppRef = e.SuppRef;
                            dup.ETA_ETD = e.ETA_ETD;
                            dup.ApproveUser = e.ApproveUser;
                            dup.Application = e.Application;
                            dup.last_Modify_Date = e.last_Modify_Date;
                            dup.Disposition = e.Disposition;
                            //dup.Activity = e.Activity;
                            _ctx.EDIDetail.Update(dup);
                        }

                    }

                    _ctx.EDIDetail.AddRange(eDIDetails);

                    _ctx.SaveChanges();

                    if (eDIDetails.Count > 0)
                    {
                        foreach (var e in eDIDetails)
                        {
                            _ctx.EDIActivityLog.Add(new EDIActivityLog
                            {
                                Id = Guid.NewGuid().ToString(),
                                ActivityId = e.Id,
                                UserId = null,
                                Status = "Pushed to AX/Completely Approved",
                                Category = null,
                                Comments = null,
                                Starttime = null,
                                Endtime = null,
                                PayRef = e.Payref,
                                VendorName = e.Account_Code

                            });
                        }

                        _ctx.SaveChanges();
                        var data = _ctx.Database.ExecuteSqlRaw("UpdateEDIData");
                    }
                    else
                    {
                        var data = _ctx.Database.ExecuteSqlRaw("UpdateEDIData");
                        //EDIDataDownload();
                    }

                    return new ObjectResult(new { status = "success" });

                }
            }
            catch (Exception ex)
            {

            }
            return new ObjectResult(new { status = "fail" });
        }

        [Authorize(Roles = "Administrator")]
        public IActionResult ShowUploadData()
        {
            ViewData["UserName"] = _ctx.Users.Where(x => x.IsActive == true).ToList();
            ViewData["EmailActivityList"] = _ctx.ThreadMaster.Where(x => x.IsEmail == true && x.isActive == true).ToList();
            ViewData["EdiActivityList"] = _ctx.ThreadMaster.Where(x => x.IsEmail == false && x.isActive == true).ToList();
            ViewData["MailboxStatus"] = _ctx.AccessTokenResponseMaster.Where(x => x.IsActive == true).Count();
            return View();
        }

        [HttpPost]
        public JsonResult GetData(DataTableAjaxPostModel model, string subjectLine, DateTime receivedDate, string status, string allocateTo, string emailActivity, string payref)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            IQueryable<EmailDetail> data = _ctx.Set<EmailDetail>().Include(x => x.FolderMaster).Include(x => x.EmailActivityLogs).AsQueryable();
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;

            #region Search

            if (!string.IsNullOrEmpty(subjectLine))
            {
                data = data.Where(x => x.EmailSubject.Contains(subjectLine.Trim()));
            }
            if (receivedDate != null && receivedDate != Convert.ToDateTime("1/1/0001 12:00:00 AM"))
            {
                data = data.Where(x => x.ReceivedTime.Date == receivedDate.Date);
            }
            if (!string.IsNullOrEmpty(emailActivity) && emailActivity != "--Select--" && emailActivity != "none")
            {
                data = data.Where(x => x.FolderMaster.Id == emailActivity);
            }
            if (!string.IsNullOrEmpty(status) && status != "--Select--" && status != "none")
            {
                data = data.Where(x => x.EmailActivityLogs.Status == status);
            }
            if (!string.IsNullOrEmpty(allocateTo) && allocateTo != "--Select--" && allocateTo != "none")
            {
                data = data.Where(x => x.EmailActivityLogs.UserId == allocateTo);
            }
            if (!string.IsNullOrEmpty(payref))
            {
                data = data.Where(x => x.EmailActivityLogs.PayRef.Contains(payref.Trim()));
            }
            #endregion

            #region Sort

            foreach (Order order in model.order)
            {
                Column column = model.columns[order.column];
                if (column.orderable)
                {
                    if (column.name != "userName" && column.name != "currentStatus")
                    {
                        data = data.OrderBy(column.name + " " + order.dir);
                    }
                    else
                    {
                        data = data.Where(x => x.EmailActivityLogs.Status == status.Trim()).OrderBy(column.name + " " + order.dir);
                    }
                }
            }

            #endregion

            #region Search Criteria

            IEnumerable<EmailDetailViewModel> emailDetailViewModels = data.Select(x => new EmailDetailViewModel
            {
                EId = x.Id,
                FolderId = x.FolderMaster.FolderName,
                EmailSubject = x.EmailSubject,
                ReceivedTime = x.ReceivedTime,
                PayRef = x.EmailActivityLogs.PayRef,
                InvoiceNo = x.EmailActivityLogs.InvoiceNo,
                CurrentStatus = x.EmailActivityLogs.Status,
                UserName = x.EmailActivityLogs.UserMaster.UserName,
                EmailCat = x.EmailCategory
            }).Skip(skip).Take(pageSize == -1 ? 100 : pageSize);

            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = data.Count(),
                data = emailDetailViewModels
            });


            #endregion

        }

        public JsonResult GetEDIData(DataTableAjaxPostModel model, string suppRef, string createdDate, string status, string allocateTo, string ediActivity, string payref)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            IQueryable<EDIDetail> data = _ctx.Set<EDIDetail>().Include(x => x.EDIActivityLog).AsQueryable();
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;

            #region Search

            if (!string.IsNullOrEmpty(suppRef))
            {
                data = data.Where(x => x.SuppRef.Contains(suppRef.Trim()));
            }
            if (createdDate != null && createdDate != "1/1/0001 12:00:00 AM")
            {
                data = data.Where(x => x.Invoice_date == Convert.ToDateTime(createdDate).ToString("M/dd/yyyy hh:mm:ss tt"));
            }
            if (!string.IsNullOrEmpty(ediActivity) && ediActivity != "--Select--" && ediActivity != "none")
            {
                data = data.Where(x => x.Activity == ediActivity);
            }
            if (!string.IsNullOrEmpty(status) && status != "--Select--" && status != "none")
            {
                data = data.Where(x => x.EDIActivityLog.Status == status);
            }
            if (!string.IsNullOrEmpty(allocateTo) && allocateTo != "--Select--" && allocateTo != "none")
            {
                data = data.Where(x => x.EDIActivityLog.UserId == allocateTo);
            }
            if (!string.IsNullOrEmpty(payref))
            {
                data = data.Where(x => x.Payref.Contains(payref.Trim()));
            }
            #endregion

            #region Sort

            foreach (Order order in model.order)
            {
                Column column = model.columns[order.column];
                if (column.orderable)
                {
                    if (column.name != "user" && column.name != "status")
                    {
                        data = data.OrderBy(column.name + " " + order.dir);
                    }
                    else
                    {
                        data = data.Where(x => x.EDIActivityLog.Status == status.Trim()).OrderBy(column.name + " " + order.dir);
                    }
                }
            }

            #endregion

            #region Search Criteria

            IEnumerable<EDIDetailViewModel> ediDetailViewModels = data.Select(x => new EDIDetailViewModel
            {
                EdId = x.Id,
                Account_Code = x.Account_Code,
                Payref = x.Payref,
                SuppRef = x.SuppRef,
                Invoice_date = x.Invoice_date,
                Activity = _ctx.ThreadMaster.Where(y => y.Id == x.Activity).Select(x => x.ThreadName).FirstOrDefault(),
                Status = _ctx.EDIActivityLog.Where(y => y.ActivityId == x.Id).FirstOrDefault().Status,
                User = x.EDIActivityLog.UserMaster.UserName,

            }).Skip(skip).Take(pageSize == -1 ? 100 : pageSize);

            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = data.Count(),
                data = ediDetailViewModels
            });


            #endregion
        }

        [HttpPost]
        public IActionResult EDIDataDownload(string suppRef, string createdDate, string status, string allocateTo, string ediActivity, string payref)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            IQueryable<EDIDetail> data = _ctx.Set<EDIDetail>().AsQueryable();
            List<EDIDetailViewModel> eDIDetailViewModels = new List<EDIDetailViewModel>();

            if (!string.IsNullOrEmpty(suppRef))
            {
                data = data.Where(x => x.SuppRef.Contains(suppRef.Trim()));
            }
            if (createdDate != null && createdDate != "1/1/0001 12:00:00 AM")
            {
                data = data.Where(x => x.Invoice_date == Convert.ToDateTime(createdDate).ToString("M/dd/yyyy hh:mm:ss tt"));
            }
            if (!string.IsNullOrEmpty(ediActivity) && ediActivity != "--Select--" && ediActivity != "none")
            {
                data = data.Where(x => x.Activity == ediActivity);
            }
            if (!string.IsNullOrEmpty(status) && status != "--Select--" && status != "none")
            {
                data = data.Where(x => x.EDIActivityLog.Status == status);
            }
            if (!string.IsNullOrEmpty(allocateTo) && allocateTo != "--Select--" && allocateTo != "none" && allocateTo != "null")
            {
                data = data.Where(x => x.EDIActivityLog.UserId == allocateTo);
            }
            if (!string.IsNullOrEmpty(payref))
            {
                data = data.Where(x => x.Payref.Contains(payref.Trim()));
            }

            eDIDetailViewModels = data.Select(x => new EDIDetailViewModel
            {
                EdId = x.Id,
                Account_Code = x.Account_Code,
                Payref = x.Payref,
                SuppRef = x.SuppRef,
                Invoice_date = x.Invoice_date,
                Activity = _ctx.ThreadMaster.Where(y => y.Id == x.Activity).Select(x => x.ThreadName).FirstOrDefault(),
                Status = _ctx.EDIActivityLog.Where(y => y.ActivityId == x.Id).FirstOrDefault().Status,
                User = x.EDIActivityLog.UserMaster.UserName,

            }).ToList();


            DataTable dt = ToDataTable(eDIDetailViewModels);

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Activity Log";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"EDIUploadedData-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }

        }

        [HttpPost]
        public IActionResult EmailDataDownload(string subjectLine, DateTime receivedDate, string status, string allocateTo, string emailActivity, string payref)
        {

            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            string easternZoneId = "India Standard Time";

            IQueryable<EmailDetail> data = _ctx.Set<EmailDetail>().AsQueryable();
            List<EmailDetailViewModel> emailDetailViewModels = new List<EmailDetailViewModel>();

            if (!string.IsNullOrEmpty(subjectLine))
            {
                data = data.Where(x => x.EmailSubject.Contains(subjectLine.Trim()));
            }
            if (receivedDate != null && receivedDate != Convert.ToDateTime("1/1/0001 12:00:00 AM"))
            {
                data = data.Where(x => x.ReceivedTime.Date == receivedDate.Date);
            }
            if (!string.IsNullOrEmpty(emailActivity) && emailActivity != "--Select--" && emailActivity != "none")
            {
                data = data.Where(x => x.FolderMaster.Id == emailActivity);
            }
            if (!string.IsNullOrEmpty(status) && status != "--Select--" && status != "none")
            {
                data = data.Where(x => x.EmailActivityLogs.Status == status);
            }
            if (!string.IsNullOrEmpty(allocateTo) && allocateTo != "--Select--" && allocateTo != "none")
            {
                data = data.Where(x => x.EmailActivityLogs.UserId == allocateTo);
            }
            if (!string.IsNullOrEmpty(payref))
            {
                data = data.Where(x => x.EmailActivityLogs.PayRef.Contains(payref.Trim()));
            }

            emailDetailViewModels = data.Include(x => x.FolderMaster).Select(x => new EmailDetailViewModel
            {
                EId = x.Id,
                FolderId = x.FolderMaster.FolderName,
                EmailSubject = x.EmailSubject,
                ReceivedTime = TimeZoneInfo.ConvertTimeFromUtc(x.ReceivedTime, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                PayRef = x.EmailActivityLogs.PayRef,
                InvoiceNo = x.EmailActivityLogs.InvoiceNo,
                CurrentStatus = x.EmailActivityLogs.Status,
                Category = x.EmailActivityLogs.Category,
                UserName = x.EmailActivityLogs.UserMaster.UserName,
                EmailCat = x.EmailCategory

            }).ToList();

            DataTable dt = ToDataTable(emailDetailViewModels);

            using (XLWorkbook wb = new XLWorkbook())
            {
                dt.TableName = "Email Log";

                var wsFileData = wb.Worksheets.Add(dt);

                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    string excelname = $"EmailReceivedData-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                }
            }

        }

        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        [Authorize(Roles = "Administrator")]
        public IActionResult Report()
        {
            return View();
        }

        //[HttpPost]
        public IActionResult GetReport(DateTime? StartDate, DateTime? EndDate)
        {
            string easternZoneId = "India Standard Time";

            if (StartDate != null && EndDate != null)
            {
                var result = _ctx.EmailActivityLog.Include(x => x.EmailDetail).Where(x => x.Starttime.Value.Date >= StartDate.Value.Date && x.Endtime <= EndDate.Value.Date).Select(x => new EmailProduction
                {
                    ProcessedDate = x.Endtime.Value.Date,
                    Emailsubject = x.EmailDetail.EmailSubject,
                    Sender = x.EmailDetail.Sender,
                    ReceivedTime = x.EmailDetail.ReceivedTime,
                    EmailFolder = x.EmailDetail.FolderMaster.FolderName,
                    Invoiceno = x.InvoiceNo,
                    Payrefno = x.PayRef,
                    Vendor = x.VendorName,
                    Comments = x.Comments,
                    EmailCategory = x.Category,
                    EmailStatus = x.Status,
                    ProcessedBy = x.UserMaster.UserName,
                    ProcessStartTime = TimeZoneInfo.ConvertTimeFromUtc(x.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    ProcessEndTime = TimeZoneInfo.ConvertTimeFromUtc(x.Endtime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    TotalTimeTakenInSec = (int)x.Endtime.Value.Subtract(x.Starttime.Value).TotalSeconds,
                    Chcklist = _ctx.EmailCheckListLog.Where(y => y.EmailActivitylogId == x.Id).Select(x => x.IsChecked).FirstOrDefault() == true ? "YES" : "NO",

                }).ToList();

                var result1 = _ctx.EDIActivityLog.Include(x => x.EDIDetail).Where(x => x.Starttime.Value.Date >= StartDate.Value.Date && x.Endtime <= EndDate.Value.Date).Select(x => new EDIProduction
                {
                    ProcessedDate = x.Endtime.Value.Date,
                    SupplierRef = x.EDIDetail.SuppRef,
                    Amount = x.EDIDetail.AMOUNT,
                    Payrefno = x.PayRef,
                    Vendor = x.VendorName,
                    CreatedDate = x.EDIDetail.Date_Create,
                    EDIStatus = x.Status,
                    EDICategory = x.Category,
                    ProcessStartTime = TimeZoneInfo.ConvertTimeFromUtc(x.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    ProcessEndTime = TimeZoneInfo.ConvertTimeFromUtc(x.Endtime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    ProcessedBy = x.UserMaster.UserName,
                    Activity = _ctx.ThreadMaster.Where(y => y.Id == x.EDIDetail.Activity).Select(x => x.ThreadName).FirstOrDefault(),
                    TotalTimeTakenInSec = (int)x.Endtime.Value.Subtract(x.Starttime.Value).TotalSeconds,
                    Chcklist = _ctx.EDICheckListLog.Where(y => y.EDIActivitylogId == x.Id).Select(x => x.IsChecked).FirstOrDefault() == true ? "YES" : "NO",

                }).ToList();

                var result2 = _ctx.EdiActivityLogHistory.Include(x => x.EDIActivityLog).Where(x => x.Starttime.Value.Date >= StartDate.Value.Date && x.Endtime <= EndDate.Value.Date).Select(x => new EDILogHistoryProduction
                {
                    ProcessedDate = x.Endtime.Value.Date,
                    SupplierRef = x.EDIActivityLog.EDIDetail.SuppRef,
                    Amount = x.EDIActivityLog.EDIDetail.AMOUNT,
                    Payrefno = x.PayRef,
                    Vendor = x.VendorName,
                    CreatedDate = x.EDIActivityLog.EDIDetail.Date_Create,
                    PreviousStatus = x.Status,
                    PreviousCategory = x.Category,
                    PreviousComments = x.Comments,
                    PreviousProcessStartTime = TimeZoneInfo.ConvertTimeFromUtc(x.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    PreviousProcessEndTime = TimeZoneInfo.ConvertTimeFromUtc(x.Endtime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    ProcessedBy = x.UserMaster.UserName,
                    PreviousApprovedUser = x.ApprovedUser,
                    PreviousLastmodifiedDate = x.Lastmodifieddate,

                }).ToList();

                DataTable dt = ToDataTable(result);
                DataTable dtt = ToDataTable(result1);
                DataTable ediloghistory = ToDataTable(result2);
                using (XLWorkbook wb = new XLWorkbook())
                {
                    dt.TableName = "Email Activity Log";
                    dtt.TableName = "EDI Activity Log";
                    ediloghistory.TableName = "EDI Activity Log History";
                    var wsEmailData = wb.Worksheets.Add(dt);
                    var wsEdiData = wb.Worksheets.Add(dtt);
                    var wsEDIloghistoryData = wb.Worksheets.Add(ediloghistory);
                    //wb.Worksheets.Add(dt);

                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        string excelname = $"UserProductionReport-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    }
                }
            }
            else
            {
                return File("ABC", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "ANV");
            }
        }

        public IActionResult getReportByReceivedDate(DateTime? RecStartDate, DateTime? RecEndDate)
        {
            string easternZoneId = "India Standard Time";

            if (RecStartDate != null && RecEndDate != null)
            {
                var result = _ctx.EmailDetail.Include(x => x.EmailActivityLogs).Where(x => x.ReceivedTime.Date >= RecStartDate.Value.Date && x.ReceivedTime.Date <= RecEndDate.Value.Date).Select(x => new EmailProduction
                {
                    ProcessedDate = x.EmailActivityLogs.Endtime.Value.Date,
                    Emailsubject = x.EmailSubject,
                    ReceivedTime = x.ReceivedTime,
                    EmailFolder = x.FolderMaster.FolderName,
                    Invoiceno = x.EmailActivityLogs.InvoiceNo,
                    Payrefno = x.EmailActivityLogs.PayRef,
                    Vendor = x.EmailActivityLogs.VendorName,
                    Comments = x.EmailActivityLogs.Comments,
                    ProcessedBy = x.EmailActivityLogs.UserMaster.UserName,
                    ProcessStartTime = x.EmailActivityLogs.Starttime.Value == null ? null : TimeZoneInfo.ConvertTimeFromUtc(x.EmailActivityLogs.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)), //TimeZoneInfo.ConvertTimeFromUtc(x.EmailActivityLogs.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)), 
                    ProcessEndTime = x.EmailActivityLogs.Endtime.Value == null ? null : TimeZoneInfo.ConvertTimeFromUtc(x.EmailActivityLogs.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)), //TimeZoneInfo.ConvertTimeFromUtc(x.EmailActivityLogs.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                                                                                                                                                                                                                  //TotalTimeTakenInSec = (int)x.EmailActivityLogs.Endtime.Value.Subtract(x.EmailActivityLogs.Starttime.Value).TotalSeconds,
                                                                                                                                                                                                                  //Chcklist = _ctx.EmailCheckListLog.Where(y => y.EmailActivitylogId == x.EmailActivityLogs.Id).Select(x => x.IsChecked).FirstOrDefault() == true ? "YES" : "NO"

                }).ToList();

                DataTable dt = ToDataTable(result);
                using (XLWorkbook wb = new XLWorkbook())
                {
                    dt.TableName = "sheet1";

                    var wsFileData = wb.Worksheets.Add(dt);

                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        string excelname = $"ReceivedDateWiseReport-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    }
                }
            }
            else
            {
                return File("ABC", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "ANV");
            }
        }

        public IActionResult getReportByCreatedDate(DateTime? CreStartDate, DateTime? CreEndDate)
        {
            string easternZoneId = "India Standard Time";
            if (CreStartDate != null && CreEndDate != null)
            {
                var result = _ctx.EDIDetail.Include(x => x.EDIActivityLog).Where(x => x.Date_Create.Value.Date >= CreStartDate.Value.Date && x.Date_Create.Value.Date <= CreEndDate.Value.Date).Select(x => new EDIProduction
                {
                    ProcessedDate = x.EDIActivityLog.Endtime.Value.Date,
                    SupplierRef = x.SuppRef,
                    Amount = x.AMOUNT,
                    Payrefno = x.Payref,
                    Vendor = x.Account_Code,
                    Comments = x.EDIActivityLog.Comments,
                    CreatedDate = x.Date_Create,
                    ProcessedBy = x.EDIActivityLog.UserMaster.UserName,
                    ProcessStartTime = x.EDIActivityLog.Starttime.Value == null ? null : TimeZoneInfo.ConvertTimeFromUtc(x.EDIActivityLog.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    ProcessEndTime = x.EDIActivityLog.Starttime.Value == null ? null : TimeZoneInfo.ConvertTimeFromUtc(x.EDIActivityLog.Starttime.Value, TimeZoneInfo.FindSystemTimeZoneById(easternZoneId)),
                    //TotalTimeTakenInSec = (int)x.EDIActivityLog.Endtime.Value.Subtract(x.EDIActivityLog.Starttime.Value).TotalSeconds,
                    //Chcklist = _ctx.EDICheckListLog.Where(y => y.EDIActivitylogId == x.EDIActivityLog.Id).Select(x => x.IsChecked).FirstOrDefault() == true ? "YES" : "NO"

                }).ToList();

                DataTable dt = ToDataTable(result);
                using (XLWorkbook wb = new XLWorkbook())
                {
                    dt.TableName = "sheet1";

                    var wsFileData = wb.Worksheets.Add(dt);

                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        string excelname = $"EdiCreatedDateWiseReport-{DateTime.UtcNow.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    }
                }
            }
            else
            {
                return File("ABC", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "ANV");
            }
        }

        public JsonResult MultiAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multilist in model.multiSelectViewModels)
                {
                    if (model.uname == null || model.uname == "none")
                    {
                        if (multilist.currentStatus != null)
                        {
                            var result1 = _ctx.EmailActivityLog.Where(x => x.ActivityId == multilist.eId && x.PayRef == multilist.Payrefno).FirstOrDefault();
                            if (result1 != null)
                            {
                                //foreach (var result1 in result)
                                //{
                                if (result1.Status == "Query" || result1.Status == "Completed" || result1.Status == "Already Processed" || result1.Status == "Pending")
                                {
                                    result1.Starttime = DateTime.UtcNow;
                                    result1.Endtime = null;
                                    result1.Status = "In Progress";
                                    _ctx.EmailActivityLog.Update(result1);
                                    _ctx.SaveChanges();
                                }
                                //}

                            }
                        }
                    }
                    else
                    {
                        if (multilist.currentStatus != null)
                        {
                            var result1 = _ctx.EmailActivityLog.Where(x => x.ActivityId == multilist.eId && x.PayRef == multilist.Payrefno).FirstOrDefault();
                            if (result1 != null)
                            {
                                //foreach (var result1 in result)
                                //{
                                if (result1.Status == "Query" || result1.Status == "Completed" || result1.Status == "Already Processed" || result1.Status == "Pending")
                                {
                                    result1.UserId = model.uname;
                                    result1.Starttime = DateTime.UtcNow;
                                    result1.Endtime = null;
                                    result1.Category = null;
                                    result1.Comments = null;
                                    result1.Status = "In Progress";
                                    _ctx.EmailActivityLog.Update(result1);
                                    _ctx.SaveChanges();
                                }
                                //}

                            }
                        }
                        else
                        {
                            var res = _ctx.EmailDetail.Where(x => x.Id == multilist.eId).FirstOrDefault();
                            if (res != null)
                            {
                                _ctx.EmailActivityLog.Add(new EmailActivityLog
                                {
                                    ActivityId = multilist.eId,
                                    UserId = model.uname,
                                    Status = "In Progress",
                                    Category = null,
                                    Comments = null,
                                    Endtime = null,
                                    Starttime = DateTime.UtcNow,
                                    PayRef = null,
                                    VendorName = null,
                                    InvoiceNo = null,
                                });
                            }
                        }
                    }
                }
            }
            else
            {
                if (model.uname == null || model.uname == "none")
                {
                    foreach (var multilist in model.ediMultiSelectViewModels)
                    {
                        //if (multilist.status == "Query")
                        //{
                        var result = _ctx.EDIActivityLog.Where(x => x.ActivityId == multilist.edId).FirstOrDefault();
                        if (result != null)
                        {
                            result.Starttime = DateTime.UtcNow;
                            result.Endtime = null;
                            result.Status = "In Progress";
                            _ctx.EDIActivityLog.Update(result);
                            _ctx.SaveChanges();
                        }
                        //}
                    }
                }
                else
                {
                    foreach (var multilist in model.ediMultiSelectViewModels)
                    {
                        if (multilist.status == "In Progress")
                        {
                            var result = _ctx.EDIActivityLog.Where(x => x.ActivityId == multilist.edId).FirstOrDefault();
                            if (result != null)
                            {
                                result.UserId = model.uname;
                                result.Starttime = DateTime.UtcNow;
                                _ctx.EDIActivityLog.Update(result);
                                _ctx.SaveChanges();
                            }
                        }
                        else
                        {
                            var res = _ctx.EDIDetail.Where(x => x.Id == multilist.edId).FirstOrDefault();
                            if (res != null)
                            {
                                _ctx.EDIActivityLog.Add(new EDIActivityLog
                                {
                                    ActivityId = multilist.edId,
                                    UserId = model.uname,
                                    Status = "In Progress",
                                    Category = null,
                                    Comments = null,
                                    Endtime = null,
                                    Starttime = DateTime.UtcNow,
                                    PayRef = null,
                                    VendorName = null,
                                });
                            }
                        }
                    }
                }
            }

            _ctx.SaveChanges();
            return Json("Success");
        }

        public JsonResult MultiDeAllocate(MultipleAllocationViewModel model)
        {
            if (model.multiSelectViewModels != null)
            {
                foreach (var multideselect in model.multiSelectViewModels)
                {
                    if (model.uname != null || model.uname != "none")
                    {
                        if (multideselect.currentStatus == "In Progress")
                        {
                            var result = _ctx.EmailActivityLog.Where(x => x.ActivityId == multideselect.eId).FirstOrDefault();
                            if (result != null)
                            {
                                result.Status = null;
                                result.UserId = null;
                                result.Starttime = null;
                                result.Endtime = null;
                                _ctx.EmailActivityLog.Update(result);
                            }
                            _ctx.SaveChanges();
                        }
                        else
                        {
                            return Json("Wrong");
                        }
                    }
                }
            }
            else
            {
                foreach (var multideselect in model.ediMultiSelectViewModels)
                {
                    if (model.uname != null || model.uname != "none")
                    {
                        if (multideselect.status == "In Progress")
                        {
                            var result = _ctx.EDIActivityLog.Where(x => x.ActivityId == multideselect.edId).FirstOrDefault();
                            if (result != null)
                            {
                                result.Status = null;
                                result.UserId = null;
                                result.Starttime = null;
                                result.Endtime = null;
                                _ctx.EDIActivityLog.Update(result);
                            }
                            _ctx.SaveChanges();
                        }
                    }
                }
            }
            return Json("Success");
        }

        public ActionResult SyncMailbox()
        {

            return RedirectToAction("Login", "Auth");
        }
        
    }
}
