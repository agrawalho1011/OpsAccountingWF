﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class EmailAndEDIChecklisttableadded1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EDICheckListLog",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EDIActivitylogId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Checklist = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EDICheckListLog", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EDICheckListLog_EDIActivityLog_EDIActivitylogId",
                        column: x => x.EDIActivitylogId,
                        principalTable: "EDIActivityLog",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EmailCheckListLog",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EmailActivitylogId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Checklist = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmailCheckListLog", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmailCheckListLog_EmailActivityLog_EmailActivitylogId",
                        column: x => x.EmailActivitylogId,
                        principalTable: "EmailActivityLog",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EDICheckListLog_EDIActivitylogId",
                table: "EDICheckListLog",
                column: "EDIActivitylogId");

            migrationBuilder.CreateIndex(
                name: "IX_EmailCheckListLog_EmailActivitylogId",
                table: "EmailCheckListLog",
                column: "EmailActivitylogId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EDICheckListLog");

            migrationBuilder.DropTable(
                name: "EmailCheckListLog");
        }
    }
}
