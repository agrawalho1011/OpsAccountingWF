﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class AccessTokenResponseMasterModified : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_AccessTokenResponseMaster",
                table: "AccessTokenResponseMaster");

            migrationBuilder.AlterColumn<string>(
                name: "id_token",
                table: "AccessTokenResponseMaster",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<string>(
                name: "Id",
                table: "AccessTokenResponseMaster",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AccessTokenResponseMaster",
                table: "AccessTokenResponseMaster",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_AccessTokenResponseMaster",
                table: "AccessTokenResponseMaster");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "AccessTokenResponseMaster");

            migrationBuilder.AlterColumn<string>(
                name: "id_token",
                table: "AccessTokenResponseMaster",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddPrimaryKey(
                name: "PK_AccessTokenResponseMaster",
                table: "AccessTokenResponseMaster",
                column: "id_token");
        }
    }
}
