﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class ActivityLogsAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Activity",
                table: "EDIDetail",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateTable(
                name: "EDIActivityLog",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Category = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EDIActivityLog", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EDIActivityLog_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EDIActivityLog_EDIDetail_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "EDIDetail",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EmailActivityLog",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ActivityId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Category = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmailActivityLog", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmailActivityLog_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_EmailActivityLog_EmailDetail_ActivityId",
                        column: x => x.ActivityId,
                        principalTable: "EmailDetail",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_EDIActivityLog_ActivityId",
                table: "EDIActivityLog",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_EDIActivityLog_UserId",
                table: "EDIActivityLog",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_EmailActivityLog_ActivityId",
                table: "EmailActivityLog",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_EmailActivityLog_UserId",
                table: "EmailActivityLog",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EDIActivityLog");

            migrationBuilder.DropTable(
                name: "EmailActivityLog");

            migrationBuilder.DropColumn(
                name: "Activity",
                table: "EDIDetail");
        }
    }
}
