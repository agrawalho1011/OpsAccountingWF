﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class EmailActivitylogHistoryTableadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EmailActivityLogHistory",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EmaillogId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Category = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Comments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PayRef = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Starttime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Endtime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    InsertedDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmailActivityLogHistory", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EmailActivityLogHistory_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_EmailActivityLogHistory_EmailActivityLog_EmaillogId",
                        column: x => x.EmaillogId,
                        principalTable: "EmailActivityLog",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_EmailActivityLogHistory_EmaillogId",
                table: "EmailActivityLogHistory",
                column: "EmaillogId");

            migrationBuilder.CreateIndex(
                name: "IX_EmailActivityLogHistory_UserId",
                table: "EmailActivityLogHistory",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmailActivityLogHistory");
        }
    }
}
