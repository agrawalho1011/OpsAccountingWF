﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class EmailmasterTokenColumnadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AuthToken",
                table: "EmailMaster",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "TokenLastUpdateDateTime",
                table: "EmailMaster",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AuthToken",
                table: "EmailMaster");

            migrationBuilder.DropColumn(
                name: "TokenLastUpdateDateTime",
                table: "EmailMaster");
        }
    }
}
