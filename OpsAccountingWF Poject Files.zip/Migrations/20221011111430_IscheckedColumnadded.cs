﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class IscheckedColumnadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsChecked",
                table: "EmailCheckListLog",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsChecked",
                table: "EDICheckListLog",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsChecked",
                table: "EmailCheckListLog");

            migrationBuilder.DropColumn(
                name: "IsChecked",
                table: "EDICheckListLog");
        }
    }
}
