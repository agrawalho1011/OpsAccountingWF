﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class ActivityLogsModified : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "Endtime",
                table: "EmailActivityLog",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "Starttime",
                table: "EmailActivityLog",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "Endtime",
                table: "EDIActivityLog",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "Starttime",
                table: "EDIActivityLog",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Endtime",
                table: "EmailActivityLog");

            migrationBuilder.DropColumn(
                name: "Starttime",
                table: "EmailActivityLog");

            migrationBuilder.DropColumn(
                name: "Endtime",
                table: "EDIActivityLog");

            migrationBuilder.DropColumn(
                name: "Starttime",
                table: "EDIActivityLog");
        }
    }
}
