﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class InvoiceDatalogTableAdded2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "InvoiceDataLog",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    EmailActivitylogId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    InvoiceNo = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InvoiceDataLog", x => x.Id);
                    table.ForeignKey(
                        name: "FK_InvoiceDataLog_EmailActivityLog_EmailActivitylogId",
                        column: x => x.EmailActivitylogId,
                        principalTable: "EmailActivityLog",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_InvoiceDataLog_EmailActivitylogId",
                table: "InvoiceDataLog",
                column: "EmailActivitylogId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "InvoiceDataLog");
        }
    }
}
