﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class EmailAndEDIChecklisttableadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_EmailActivityLog_ActivityId",
                table: "EmailActivityLog");

            migrationBuilder.DropIndex(
                name: "IX_EDIActivityLog_ActivityId",
                table: "EDIActivityLog");

            migrationBuilder.CreateIndex(
                name: "IX_EmailActivityLog_ActivityId",
                table: "EmailActivityLog",
                column: "ActivityId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_EDIActivityLog_ActivityId",
                table: "EDIActivityLog",
                column: "ActivityId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_EmailActivityLog_ActivityId",
                table: "EmailActivityLog");

            migrationBuilder.DropIndex(
                name: "IX_EDIActivityLog_ActivityId",
                table: "EDIActivityLog");

            migrationBuilder.CreateIndex(
                name: "IX_EmailActivityLog_ActivityId",
                table: "EmailActivityLog",
                column: "ActivityId");

            migrationBuilder.CreateIndex(
                name: "IX_EDIActivityLog_ActivityId",
                table: "EDIActivityLog",
                column: "ActivityId");
        }
    }
}
