﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class PAYREFandVENDORAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PayRef",
                table: "EmailActivityLog",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VendorName",
                table: "EmailActivityLog",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PayRef",
                table: "EDIActivityLog",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VendorName",
                table: "EDIActivityLog",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PayRef",
                table: "EmailActivityLog");

            migrationBuilder.DropColumn(
                name: "VendorName",
                table: "EmailActivityLog");

            migrationBuilder.DropColumn(
                name: "PayRef",
                table: "EDIActivityLog");

            migrationBuilder.DropColumn(
                name: "VendorName",
                table: "EDIActivityLog");
        }
    }
}
