﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class AddedDispositionField1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EDIDetail",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LegalEntity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Account_Code = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Supplier_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    File_Number = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    BL = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Payref = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Invoice_date = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Date_Create = table.Column<DateTime>(type: "datetime2", nullable: true),
                    DESCRIPTION = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ARInvCreatedBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AMOUNT = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Currency = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CODE = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Rejection = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SuppRef = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ETA_ETD = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ApproveUser = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Application = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    last_Modify_Date = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Disposition = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EDIDetail", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EDIDetail");
        }
    }
}
