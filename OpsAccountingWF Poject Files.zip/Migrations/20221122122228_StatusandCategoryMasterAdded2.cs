﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class StatusandCategoryMasterAdded2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_categoryMaster_statusMaster_StatusId",
                table: "categoryMaster");

            migrationBuilder.DropPrimaryKey(
                name: "PK_statusMaster",
                table: "statusMaster");

            migrationBuilder.DropPrimaryKey(
                name: "PK_categoryMaster",
                table: "categoryMaster");

            migrationBuilder.RenameTable(
                name: "statusMaster",
                newName: "StatusMaster");

            migrationBuilder.RenameTable(
                name: "categoryMaster",
                newName: "CategoryMaster");

            migrationBuilder.RenameIndex(
                name: "IX_categoryMaster_StatusId",
                table: "CategoryMaster",
                newName: "IX_CategoryMaster_StatusId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_StatusMaster",
                table: "StatusMaster",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_CategoryMaster",
                table: "CategoryMaster",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_CategoryMaster_StatusMaster_StatusId",
                table: "CategoryMaster",
                column: "StatusId",
                principalTable: "StatusMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CategoryMaster_StatusMaster_StatusId",
                table: "CategoryMaster");

            migrationBuilder.DropPrimaryKey(
                name: "PK_StatusMaster",
                table: "StatusMaster");

            migrationBuilder.DropPrimaryKey(
                name: "PK_CategoryMaster",
                table: "CategoryMaster");

            migrationBuilder.RenameTable(
                name: "StatusMaster",
                newName: "statusMaster");

            migrationBuilder.RenameTable(
                name: "CategoryMaster",
                newName: "categoryMaster");

            migrationBuilder.RenameIndex(
                name: "IX_CategoryMaster_StatusId",
                table: "categoryMaster",
                newName: "IX_categoryMaster_StatusId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_statusMaster",
                table: "statusMaster",
                column: "Id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_categoryMaster",
                table: "categoryMaster",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_categoryMaster_statusMaster_StatusId",
                table: "categoryMaster",
                column: "StatusId",
                principalTable: "statusMaster",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
