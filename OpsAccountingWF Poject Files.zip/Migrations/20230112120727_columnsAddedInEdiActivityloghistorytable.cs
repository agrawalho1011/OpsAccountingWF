﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OpsAccountingWF.Migrations
{
    public partial class columnsAddedInEdiActivityloghistorytable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ApprovedUser",
                table: "EdiActivityLogHistory",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "Lastmodifieddate",
                table: "EdiActivityLogHistory",
                type: "datetime2",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApprovedUser",
                table: "EdiActivityLogHistory");

            migrationBuilder.DropColumn(
                name: "Lastmodifieddate",
                table: "EdiActivityLogHistory");
        }
    }
}
