﻿namespace OpsAccountingWF.Models
{
	public class AllocateModel
	{
		public string Id { get; set; } 
		public string ActivityId { get; set; }
		public string UserId { get; set; } 
		public string Status { get; set; } 
		public string Category { get; set; }
		public string Comments { get; set; }
		public DateTime? Starttime { get; set; } 
		public DateTime? Endtime { get; set; }
	}
}
