﻿namespace OpsAccountingWF.Models
{
    public class EDIDetailViewModel
    {
        public string EdId { get; set; }
        public string Account_Code { get; set; }
        public string Payref { get; set; }
        public string Invoice_date { get; set; }
        public string SuppRef  { get; set; }
        public string Activity { get; set; }
        public string Status { get; set; }
        public string User { get; set; }
    }
}
