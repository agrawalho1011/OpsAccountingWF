﻿namespace OpsAccountingWF.Models
{
    public class EDIActivityLogViewModel
    {
        public string Id { get; set; }
        public string Status { get; set; }
        public string? Category { get; set; }
        public string? Comments { get; set; }
        public string? Payref { get; set; }
        public string? Vendor { get; set; }
        public string? Chklist { get; set; }
        public string? UnChklist { get; set; }
        //public string? EdiList { get; set; }
    }
}
