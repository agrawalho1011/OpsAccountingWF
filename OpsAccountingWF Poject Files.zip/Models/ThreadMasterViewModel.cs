﻿namespace OpsAccountingWF.Models
{
    public class ThreadMasterViewModel
    {
		public string Id { get; set; } = Guid.NewGuid().ToString();
		public string ThreadName { get; set; } = string.Empty;
		public bool IsEmail { get; set; } 
		public string ThreadFolderId { get; set; } = string.Empty;
		public DateTime CreatedDateTime { get; set; } = DateTime.UtcNow;
		public bool isActive { get; set; } 
	}
}
