﻿namespace OpsAccountingWF.Models
{
    public class EmailActivityLogViewModel
    {
        public string Id { get; set; }
        public string? EmailCategory { get; set; }
        public List<EmailList> EmailLists { get; set; }
        public List<CheckList> CheckLists { get; set; }
    }
    public class EmailList
    {
        public string InvoiceId { get; set; }
        public string Status { get; set; }
        public string? Category { get; set; }
        public string? Comments { get; set; }
        public string? Payref { get; set; }
        public string? Vendor { get; set; }
        public string? Remark { get; set; }
        public string? InvoiceNumber { get; set; }
        //public List<CheckList> CheckLists { get; set; }
    }
    public class CheckList
    {
        public string? EmailActivitylogId { get; set; }
        //public List<Multichecklist> Multichecklists { get; set; }
        public string? ChecklistName { get; set; }
        public bool CheckListValue { get; set; }
        public string? PayrefNo { get; set; }
    }
    //public class Multichecklist
    //{
    //    public string? ChecklistName { get; set; }
    //    public bool CheckListValue { get; set; }
    //    public string? PayrefNo { get; set; }
    //}
}
