﻿namespace OpsAccountingWF.Models
{
    public class DashboardModel
    {
		public string FolderId { get; set; }
		public string FolderName { get; set; }
		//public string User { get; set; }
		//public string Thread { get; set; }
		//public string Status { get; set; }
		//public int? Count { get; set; }
		public int? Days { get; set; }
		public int? Hours { get; set; }
		public int? Pending { get; set; }
		public int? Completed { get; set; }
		public int Total { get; set; }
		
	}
	

}
