﻿namespace OpsAccountingWF.Models
{
    public class MapMasterViewModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string? Account { get; set; }
        public string CompanyName { get; set; }
        public string Type { get; set; }
        public string ActivityType { get; set; }
    }
}
