﻿namespace OpsAccountingWF.Models
{
    public class ReportViewModel
    {
        public DateTime? SDate { get; set; }
        public DateTime? EDate { get; set; }
        public DateTime? REDate { get; set; }
        public DateTime? CRDate { get; set; }

    }
}
