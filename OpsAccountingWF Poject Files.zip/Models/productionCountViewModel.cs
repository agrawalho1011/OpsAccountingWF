﻿namespace OpsAccountingWF.Models
{
    public class productionCountViewModel
    {
        public int? EmailProcessed { get; set; }    
        public int? EdiProcessed { get; set; }
        public int? Total { get; set; }
        public int? TotalAllocated { get; set; }
        public string? ThreadName { get; set; }
        public string? Type { get; set; }

    }
}
