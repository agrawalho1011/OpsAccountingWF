﻿namespace OpsAccountingWF.Models
{
    public class UserDashboardModel
    {
        public string User { get; set; }
        public int? Count { get; set; }
        public List<ThreadCount> ThreadData { get; set; }
        public List<EDIThreadCount> EDIThreadData { get; set; }
    }
    public class ThreadCount
    {
        
        public string Thread { get; set; }
        public string Status { get; set; }
        public int? Count { get; set; }
    }

    public class EDIThreadCount
    {

        public string Thread { get; set; }
        public string Status { get; set; }
        public int? Count { get; set; }
    }
}
