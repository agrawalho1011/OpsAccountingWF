﻿namespace OpsAccountingWF.Models
{
    public class MultipleAllocationViewModel
    {
        public string uname { get; set; }   
        public List<MultiSelectViewModel> multiSelectViewModels { get; set; }
        public List<EdiMultiSelectViewModel> ediMultiSelectViewModels { get; set; }
    }

    public class MultiSelectViewModel
    {
        public string eId { get; set; }
        public string folderName { get; set; }
        public string emailSubject { get; set; }
        public DateTime? receivedTime { get; set; }
        public string currentStatus { get; set; }
        public string userName { get; set; }
        public string Payrefno { get; set; }
    }
    public class EdiMultiSelectViewModel
    {
        public string edId { get; set; }    
        public string accountCode { get; set; }
        public string payRef { get; set; }
        public string invoiceDate { get; set; }
        public string supplierRef { get; set; }
        public string activity { get; set; }
        public string status { get; set; }
        public string user { get; set; }
    }
}
