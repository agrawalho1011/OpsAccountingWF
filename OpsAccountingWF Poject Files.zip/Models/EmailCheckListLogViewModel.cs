﻿namespace OpsAccountingWF.Models
{
    public class EmailCheckListLogViewModel
    {
       //public List<CheckList> CheckLists { get; set; }
    }
    //public class CheckList
    //{
    //    public string? EmailActivitylogId { get; set; }
    //    public string? ChecklistName { get; set; }
    //    public bool? CheckListValue { get; set; }
    //}
}
