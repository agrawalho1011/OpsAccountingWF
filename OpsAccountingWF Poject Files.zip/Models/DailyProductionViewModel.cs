﻿namespace OpsAccountingWF.Models
{
    public class DailyProductionViewModel
    {

        public string? Username { get; set; }
        public int? Total { get; set; }
        public int? Email { get; set; }
        public int? EDI { get; set; }
        public int? EmailCount { get; set; }
        public int? EDICount { get; set; }
        public int? TotalProd { get; set; }
    }

}
