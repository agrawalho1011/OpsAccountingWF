﻿namespace OpsAccountingWF.Models
{
    public class EDIDetailCrossCheckViewModel
    {
		public string Id { get; set; } = Guid.NewGuid().ToString();
		public string LegalEntity { get; set; } = string.Empty;
		public string Account_Code { get; set; } = string.Empty;
		public string Supplier_Name { get; set; } = string.Empty;
		public string File_Number { get; set; } = string.Empty;
		public string BL { get; set; } = string.Empty;
		public string Type { get; set; } = string.Empty;
		public string Payref { get; set; } = string.Empty;
		public string Invoice_date { get; set; } = string.Empty;
		public DateTime? Date_Create { get; set; }
		public string DESCRIPTION { get; set; } = string.Empty;
		public string ARInvCreatedBy { get; set; } = string.Empty;
		public double? AMOUNT { get; set; }
		public string Currency { get; set; } = string.Empty;
		public string CODE { get; set; } = string.Empty;
		public string Rejection { get; set; } = string.Empty;
		public string SuppRef { get; set; } = string.Empty;
		public string ETA_ETD { get; set; } = string.Empty;
		public string ApproveUser { get; set; } = string.Empty;
		public string Application { get; set; } = string.Empty;
		public DateTime? last_Modify_Date { get; set; }
		public string Disposition { get; set; } = string.Empty;
		public string Activity { get; set; } = string.Empty;
		public string Status { get; set; }
		public string User { get; set; }
	}
}
