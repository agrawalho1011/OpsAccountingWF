﻿namespace OpsAccountingWF.Models
{
    public class FreeTextFormViewModel
    {
        public string Status { get; set; }
        public string? Category { get; set; }
        public string? Comments { get; set; }
        public string? Payref { get; set; }
        public string? Vendor { get; set; }
        public string? Suppref { get; set; }
        public double? Amt { get; set; }
        public List<FreeTextCheckList> CheckLists { get; set; }
    }
    public class FreeTextCheckList
    {
        public string? ChecklistName { get; set; }
        public bool CheckListValue { get; set; }
        public string? PayrefNo { get; set; }
    }
}
