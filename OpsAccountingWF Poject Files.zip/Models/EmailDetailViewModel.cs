﻿namespace OpsAccountingWF.Models
{
    public class EmailDetailViewModel
    {
		public string EId { get; set; }
		public string FolderId { get; set; }
		public string EmailSubject { get; set; }
		public DateTime ReceivedTime { get; set; }
		public string UserName { get; set; }
		public string CurrentStatus { get; set; }
		public string Category { get; set; }
		public string EmailCat { get; set; }
		public string PayRef { get; set; }
		public string InvoiceNo { get; set; }
		//public string AllocatedTo { get; set; }
	}
}
