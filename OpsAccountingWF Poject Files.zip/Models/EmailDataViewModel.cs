﻿namespace OpsAccountingWF.Models
{
    public class EmailDataViewModel
    {
        public string? EmailSubject { get; set; }
		public string? Emailcategory { get; set; }
        public string? FolderName { get; set; }
        public DateTime? ReceivedDate { get; set; }
		public string? Category { get; set; }
		public string? Comments { get; set; }
		public string? PayRef { get; set; }
		public string? InvoiceNo { get; set; }
		public string? VendorName { get; set; }
		public string UserId { get; set; } 
		public string Status { get; set; } 
		public DateTime? Starttime { get; set; }
		public DateTime? Endtime { get; set; }
		public string? Sender { get; set; }
	}
}
