﻿namespace OpsAccountingWF.Models
{
    public class UserRolesViewModel
    {
        public string UserId { get; set; }
        public string RoleId { get; set; }
    }
}
