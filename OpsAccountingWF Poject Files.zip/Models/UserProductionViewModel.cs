﻿namespace OpsAccountingWF.Models
{
    public class UserProductionViewModel
    {
        public List<EmailProduction> EmailProductions { get; set; }
        public List<EDIProduction> EDIProductions { get; set; }
        public List<EDILogHistoryProduction> EDILogHistoryProductions { get; set; }
    }

    public class EmailProduction
    {
        public DateTime? ProcessedDate { get; set; }
        public string Emailsubject { get; set; }    
        public string Sender { get; set; }
        public string EmailFolder { get; set; }
        public DateTime? ReceivedTime { get; set; }
        public string EmailStatus { get; set; }
        public string EmailCategory { get; set; }
        public string Comments { get; set; }
        public string Payrefno { get; set; }
        public string Vendor { get; set; }
        public string Invoiceno { get; set; }
        public string ProcessedBy { get; set; }
        public DateTime? ProcessStartTime { get; set; }
        public DateTime? ProcessEndTime { get; set; }
        public int? TotalTimeTakenInSec { get; set; }
        public string? Chcklist { get; set; }
    }

    public class EDIProduction
    {
        public DateTime? ProcessedDate { get; set; }
        public string SupplierRef { get; set; }
        public double? Amount { get; set; }
        public string Payrefno { get; set; }
        public string Vendor { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string EDIStatus { get; set; }
        public string EDICategory { get; set; }
        public string Comments { get; set; }
        public string ProcessedBy { get; set; }
        public DateTime? ProcessStartTime { get; set; }
        public DateTime? ProcessEndTime { get; set; }
        public string Activity { get; set; }
        public int? TotalTimeTakenInSec { get; set; }
        public string? Chcklist { get; set; }
    }

    public class EDILogHistoryProduction
    {
        public DateTime? ProcessedDate { get; set; }
        public string SupplierRef { get; set; }
        public double? Amount { get; set; }
        public string Payrefno { get; set; }
        public string Vendor { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string PreviousStatus { get; set; }
        public string PreviousCategory { get; set; }
        public string PreviousComments { get; set; }
        public string ProcessedBy { get; set; }
        public string PreviousApprovedUser { get; set; }
        public DateTime? PreviousLastmodifiedDate { get; set; }
        public DateTime? PreviousProcessStartTime { get; set; }
        public DateTime? PreviousProcessEndTime { get; set; }
        
    }
}
