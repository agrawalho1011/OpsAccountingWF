﻿using System.ComponentModel.DataAnnotations;

namespace OpsAccountingWF.Models
{
	public class RegisterViewModel
	{
		[Required]
		public string UserName { get; set; }
		[Required]
		public string Wnsid { get; set; }
		[Required]
		public string CitrixId { get; set; }

		public string Role { get; set; }
		public string? UserId { get; set; }
		public bool? isActive { get; set; }
	}
}
